import "@/App.css";
import { Toaster } from "sonner";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { AuthLanding } from "@/pages/AuthLanding";
import { CustomerApp } from "@/pages/CustomerApp";
import { WasherApp } from "@/pages/WasherApp";
import { AdminApp } from "@/pages/AdminApp";
import { NotificationBell } from "@/components/NotificationBell";
import { useAuth, clearAuth } from "@/lib/auth";
import { LogOut } from "lucide-react";

function App() {
  const auth = useAuth();

  return (
    <div className="App min-h-screen lava-grid-bg" data-testid="app-root">
      <Toaster position="top-right" richColors />
      {!auth ? (
        <AuthLanding />
      ) : (
        <>
          <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
              <Logo />
              <div className="flex items-center gap-3">
                <div className="hidden sm:block text-right">
                  <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">{auth.user.role === "customer" ? "Cliente" : auth.user.role === "washer" ? "Lavador" : "Admin"}</div>
                  <div className="text-sm font-semibold text-slate-900">{auth.user.name}</div>
                </div>
                {(auth.user.role === "customer" || auth.user.role === "washer") && <NotificationBell />}
                <Button size="sm" variant="outline" onClick={clearAuth} data-testid="logout-btn" className="rounded-full border-slate-200">
                  <LogOut size={14} className="mr-1.5" /> Salir
                </Button>
              </div>
            </div>
          </header>
          <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
            {auth.user.role === "customer" && <CustomerApp customer={auth.user} />}
            {auth.user.role === "washer" && <WasherApp washer={auth.user} />}
            {auth.user.role === "admin" && <AdminApp />}
          </main>
          <footer className="border-t border-slate-200 bg-white/60 mt-10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 text-center text-xs text-slate-500">
              <span className="font-semibold text-slate-700">LAVADOSYA!</span> · Prototipo privado · Sin pagos reales en gateway
            </div>
          </footer>
        </>
      )}
    </div>
  );
}

export default App;
