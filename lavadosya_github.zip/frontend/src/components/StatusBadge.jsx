import { STATUS_LABELS, STATUS_STYLES } from "../lib/format";

export const StatusBadge = ({ status, size = "sm" }) => {
  const cls = STATUS_STYLES[status] || "bg-slate-50 text-slate-700 border-slate-200";
  const pad = size === "lg" ? "px-3.5 py-1.5 text-sm" : "px-2.5 py-0.5 text-xs";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-semibold ${cls} ${pad}`}
      data-testid={`status-badge-${status}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {STATUS_LABELS[status] || status}
    </span>
  );
};
