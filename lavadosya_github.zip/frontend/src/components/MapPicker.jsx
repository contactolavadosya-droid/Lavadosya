import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const DEFAULT_CENTER = [-34.6037, -58.3816]; // Obelisco BA

export const MapPicker = ({ lat, lng, onChange, height = 260, readOnly = false, washerLat, washerLng }) => {
  const ref = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const washerMarkerRef = useRef(null);

  useEffect(() => {
    if (!ref.current || mapRef.current) return;
    const start = lat && lng ? [lat, lng] : DEFAULT_CENTER;
    const map = L.map(ref.current, { zoomControl: true }).setView(start, lat && lng ? 15 : 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
      maxZoom: 19,
    }).addTo(map);
    const marker = L.marker(start, { draggable: !readOnly }).addTo(map);
    marker.on("dragend", () => {
      const p = marker.getLatLng();
      onChange?.({ lat: p.lat, lng: p.lng });
    });
    if (!readOnly) {
      map.on("click", (e) => {
        marker.setLatLng(e.latlng);
        onChange?.({ lat: e.latlng.lat, lng: e.latlng.lng });
      });
    }
    mapRef.current = map;
    markerRef.current = marker;
    // ensure proper sizing
    setTimeout(() => map.invalidateSize(), 100);
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []); // eslint-disable-line

  useEffect(() => {
    if (mapRef.current && lat && lng) {
      markerRef.current?.setLatLng([lat, lng]);
      mapRef.current.setView([lat, lng], 15);
    }
  }, [lat, lng]);

  useEffect(() => {
    if (!mapRef.current || !washerLat || !washerLng) return;
    const icon = L.divIcon({
      className: "washer-marker",
      html:
        '<div style="background:#0052FF;color:white;border-radius:999px;padding:4px 10px;font-size:11px;font-weight:700;box-shadow:0 4px 12px rgba(0,82,255,.4);white-space:nowrap">🚐 Lavador</div>',
      iconSize: [80, 24],
    });
    if (washerMarkerRef.current) washerMarkerRef.current.remove();
    washerMarkerRef.current = L.marker([washerLat, washerLng], { icon }).addTo(mapRef.current);
  }, [washerLat, washerLng]);

  return (
    <div
      ref={ref}
      style={{ height, borderRadius: 16, overflow: "hidden", border: "1px solid #e2e8f0" }}
      data-testid="map-picker"
    />
  );
};
