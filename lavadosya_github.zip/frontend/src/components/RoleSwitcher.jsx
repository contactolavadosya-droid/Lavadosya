import { Car, Wrench, ShieldCheck } from "lucide-react";

const ROLES = [
  { id: "customer", label: "Cliente", icon: Car },
  { id: "washer", label: "Lavador", icon: Wrench },
  { id: "admin", label: "Admin", icon: ShieldCheck },
];

export const RoleSwitcher = ({ current, onChange }) => {
  return (
    <div
      className="inline-flex items-center gap-1 p-1 rounded-full bg-slate-100/80 backdrop-blur border border-slate-200"
      data-testid="role-switcher"
    >
      {ROLES.map((r) => {
        const Icon = r.icon;
        const active = current === r.id;
        return (
          <button
            key={r.id}
            onClick={() => onChange(r.id)}
            data-testid={`role-switcher-${r.id}`}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 h-9 text-sm font-semibold transition-all ${
              active
                ? "bg-blue-600 text-white shadow-md shadow-blue-500/30"
                : "text-slate-600 hover:text-slate-900 hover:bg-white"
            }`}
          >
            <Icon size={16} />
            <span className="hidden sm:inline">{r.label}</span>
          </button>
        );
      })}
    </div>
  );
};
