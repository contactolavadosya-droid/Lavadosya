import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { listMessages, sendMessage } from "@/lib/api";
import { Send, MessageCircle } from "lucide-react";

export const ChatDialog = ({ booking, me, onClose }) => {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  const load = async () => {
    try {
      const data = await listMessages(booking.id);
      setMessages(data);
    } catch {}
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 2000);
    return () => clearInterval(t);
  }, [booking.id]); // eslint-disable-line

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  const submit = async (e) => {
    e?.preventDefault();
    if (!text.trim()) return;
    try {
      setSending(true);
      await sendMessage(booking.id, text.trim());
      setText("");
      load();
    } catch (err) {
      toast.error("No se pudo enviar");
    } finally {
      setSending(false);
    }
  };

  const other = me.role === "customer" ? booking.washer_name || "Lavador" : booking.customer_name;

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="chat-dialog">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle size={18} className="text-blue-600" />
            Chat con {other}
          </DialogTitle>
        </DialogHeader>
        <div
          ref={scrollRef}
          className="h-80 overflow-y-auto bg-slate-50 rounded-xl p-3 space-y-2 border border-slate-200"
          data-testid="chat-messages"
        >
          {messages.length === 0 ? (
            <div className="text-center text-slate-400 text-sm py-10">
              Todavía no hay mensajes.
              <br />
              Escribí el primero para coordinar la llegada.
            </div>
          ) : (
            messages.map((m) => {
              const mine = m.sender_id === me.id;
              return (
                <div
                  key={m.id}
                  className={`flex ${mine ? "justify-end" : "justify-start"}`}
                  data-testid={`chat-msg-${m.id}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${
                      mine
                        ? "bg-blue-600 text-white rounded-br-sm"
                        : "bg-white border border-slate-200 text-slate-900 rounded-bl-sm"
                    }`}
                  >
                    {!mine && (
                      <div className="text-[10px] font-semibold uppercase tracking-wider opacity-70 mb-0.5">
                        {m.sender_name}
                      </div>
                    )}
                    <div className="whitespace-pre-wrap break-words">{m.text}</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
        <form onSubmit={submit} className="flex items-center gap-2">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Escribí un mensaje…"
            data-testid="chat-input"
            className="h-11"
            maxLength={800}
          />
          <Button
            type="submit"
            disabled={sending || !text.trim()}
            data-testid="chat-send-btn"
            className="h-11 w-11 p-0 bg-blue-600 hover:bg-blue-700 rounded-full"
          >
            <Send size={16} />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};
