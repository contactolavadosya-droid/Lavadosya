import { Droplets } from "lucide-react";

export const Logo = ({ size = "md", invert = false }) => {
  const dim = size === "sm" ? "h-8 w-8" : size === "lg" ? "h-12 w-12" : "h-10 w-10";
  const text = size === "sm" ? "text-lg" : size === "lg" ? "text-3xl" : "text-2xl";
  return (
    <div className="flex items-center gap-2.5" data-testid="brand-logo">
      <div
        className={`${dim} rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 flex items-center justify-center shadow-lg shadow-blue-500/30 lava-shine`}
      >
        <Droplets className="text-white" strokeWidth={2.5} size={size === "sm" ? 18 : 22} />
      </div>
      <div className="flex items-baseline gap-0.5">
        <span className={`font-display font-extrabold ${text} ${invert ? "text-white" : "text-slate-900"} tracking-tight`}>
          LAVADOSYA
        </span>
        <span className={`font-display font-extrabold ${text} text-blue-600`}>!</span>
      </div>
    </div>
  );
};
