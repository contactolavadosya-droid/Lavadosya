import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Bell, Check } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { listNotifications, markNotifRead, markAllNotifRead } from "@/lib/api";

const timeAgo = (iso) => {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "ahora";
  if (diff < 3600) return `hace ${Math.floor(diff / 60)}min`;
  if (diff < 86400) return `hace ${Math.floor(diff / 3600)}h`;
  return `hace ${Math.floor(diff / 86400)}d`;
};

export const NotificationBell = () => {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const seenIds = useRef(new Set());
  const didMount = useRef(false);

  const load = async () => {
    try {
      const data = await listNotifications();
      // Toast only on genuinely new items (not on first load)
      if (didMount.current) {
        data.forEach((n) => {
          if (!seenIds.current.has(n.id) && !n.read) {
            toast(n.title, { description: n.body });
          }
        });
      }
      data.forEach((n) => seenIds.current.add(n.id));
      setItems(data);
      didMount.current = true;
    } catch {}
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 6000);
    return () => clearInterval(t);
  }, []);

  const unread = items.filter((n) => !n.read).length;

  const markOne = async (id) => {
    await markNotifRead(id).catch(() => {});
    load();
  };
  const markAll = async () => {
    await markAllNotifRead().catch(() => {});
    load();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          data-testid="notif-bell-btn"
          className="relative h-10 w-10 rounded-full bg-white border border-slate-200 hover:border-blue-300 flex items-center justify-center transition-colors"
        >
          <Bell size={18} className="text-slate-700" />
          {unread > 0 && (
            <span
              data-testid="notif-unread-count"
              className="absolute -top-1 -right-1 h-5 min-w-[20px] px-1 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center shadow-md"
            >
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0" data-testid="notif-popover">
        <div className="p-3 flex items-center justify-between">
          <div className="font-display font-bold text-sm">Notificaciones</div>
          {unread > 0 && (
            <Button variant="ghost" size="sm" onClick={markAll} className="h-7 text-xs" data-testid="notif-mark-all">
              <Check size={12} className="mr-1" /> Marcar todas
            </Button>
          )}
        </div>
        <Separator />
        <div className="max-h-96 overflow-y-auto">
          {items.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No tenés notificaciones todavía.</div>
          ) : (
            items.map((n) => (
              <button
                key={n.id}
                onClick={() => markOne(n.id)}
                data-testid={`notif-item-${n.id}`}
                className={`w-full text-left p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors ${
                  n.read ? "opacity-70" : "bg-blue-50/30"
                }`}
              >
                <div className="flex items-start gap-2">
                  {!n.read && <span className="h-2 w-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />}
                  <div className="flex-1">
                    <div className="font-semibold text-sm text-slate-900">{n.title}</div>
                    <div className="text-xs text-slate-600 mt-0.5">{n.body}</div>
                    <div className="text-[10px] text-slate-400 mt-1 font-mono-ld uppercase tracking-wider">
                      {timeAgo(n.created_at)}
                    </div>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
