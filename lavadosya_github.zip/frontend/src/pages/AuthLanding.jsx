import { useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Logo } from "@/components/Logo";
import { registerCustomer, loginCustomer, loginStaff, loginAdmin, getWashersPublic } from "@/lib/api";
import { saveAuth } from "@/lib/auth";
import { Car, Wrench, ShieldCheck, Eye, EyeOff, Sparkles, MapPin, Clock } from "lucide-react";
import { useEffect } from "react";

const errMsg = (e, fallback) => {
  const d = e?.response?.data?.detail;
  if (Array.isArray(d)) return d.map((x) => x?.msg || JSON.stringify(x)).join(", ");
  if (typeof d === "string") return d;
  if (d) return JSON.stringify(d);
  return fallback;
};

export const AuthLanding = () => {
  return (
    <div className="min-h-screen lava-grid-bg flex flex-col" data-testid="auth-landing">
      <header className="py-4 px-5 flex items-center justify-between">
        <Logo />
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
          CABA · GBA · Prototipo
        </span>
      </header>
      <main className="flex-1 grid lg:grid-cols-[1.1fr_1fr] gap-8 items-center max-w-7xl w-full mx-auto px-5 py-6 lg:py-10">
        <HeroPane />
        <AuthPane />
      </main>
      <footer className="py-5 text-center text-xs text-slate-500">
        Prototipo privado · Sin pagos reales en gateway · Datos de prueba
      </footer>
    </div>
  );
};

const HeroPane = () => (
  <div className="hidden lg:block relative rounded-3xl overflow-hidden lava-hero-gradient p-10 text-white min-h-[520px]">
    <div className="absolute inset-0 lava-dots opacity-20" />
    <div className="relative">
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-bold uppercase tracking-wider">
        <Sparkles size={12} /> Lavado premium a domicilio
      </span>
      <h1 className="font-display text-5xl font-extrabold mt-5 leading-[1.05]">
        Tu auto impecable.
        <br />
        <span className="text-sky-200">Vamos a tu puerta.</span>
      </h1>
      <p className="mt-5 text-white/80 max-w-md">
        El lavador llega hasta tu vehículo en CABA o GBA. Elegís servicio, horario y seguís el estado en vivo.
      </p>
      <div className="mt-8 inline-flex items-center gap-3 bg-white/10 border border-white/20 rounded-2xl px-5 py-4">
        <div>
          <div className="text-xs text-white/70 font-mono-ld uppercase tracking-widest">Lavados desde</div>
          <div className="font-display font-extrabold text-4xl">$20.000</div>
        </div>
        <div className="h-10 w-px bg-white/20" />
        <ul className="text-sm space-y-1">
          <li className="flex items-center gap-1.5"><MapPin size={14} /> CABA + GBA</li>
          <li className="flex items-center gap-1.5"><Clock size={14} /> Reserva en 2 minutos</li>
        </ul>
      </div>
    </div>
  </div>
);

const AuthPane = () => {
  return (
    <Card className="p-6 sm:p-8 bg-white border-slate-100 shadow-xl shadow-slate-200/40">
      <h2 className="font-display font-extrabold text-2xl text-slate-900">Ingresá a LAVADOSYA!</h2>
      <p className="text-sm text-slate-500 mt-1">Entrá como cliente, lavador o administrador.</p>
      <Tabs defaultValue="customer" className="mt-5">
        <TabsList className="w-full grid grid-cols-3 h-11 p-1 bg-slate-100">
          <TabsTrigger value="customer" data-testid="auth-tab-customer" className="data-[state=active]:bg-white data-[state=active]:text-blue-700 font-semibold">
            <Car size={14} className="mr-1.5" /> Cliente
          </TabsTrigger>
          <TabsTrigger value="washer" data-testid="auth-tab-washer" className="data-[state=active]:bg-white data-[state=active]:text-blue-700 font-semibold">
            <Wrench size={14} className="mr-1.5" /> Soy Lavador
          </TabsTrigger>
          <TabsTrigger value="admin" data-testid="auth-tab-admin" className="data-[state=active]:bg-white data-[state=active]:text-blue-700 font-semibold">
            <ShieldCheck size={14} className="mr-1.5" /> Admin
          </TabsTrigger>
        </TabsList>
        <TabsContent value="customer" className="mt-5"><CustomerAuth /></TabsContent>
        <TabsContent value="washer" className="mt-5"><WasherAuth /></TabsContent>
        <TabsContent value="admin" className="mt-5"><AdminAuth /></TabsContent>
      </Tabs>
    </Card>
  );
};

const CustomerAuth = () => {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    try {
      setLoading(true);
      const data = mode === "login"
        ? await loginCustomer({ email, password })
        : await registerCustomer({ name, email, password, phone });
      saveAuth(data.token, data.user);
      toast.success(mode === "login" ? "¡Bienvenido!" : "¡Cuenta creada!");
    } catch (e) {
      toast.error(errMsg(e, "Error al autenticar"));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-3" data-testid="customer-auth">
      <div className="flex gap-1 p-1 bg-slate-100 rounded-full w-fit">
        {["login", "register"].map((m) => (
          <button key={m} onClick={() => setMode(m)} data-testid={`cust-mode-${m}`}
            className={`px-4 h-8 rounded-full text-xs font-semibold transition-all ${mode === m ? "bg-white text-slate-900 shadow-sm" : "text-slate-600"}`}>
            {m === "login" ? "Ya tengo cuenta" : "Crear cuenta"}
          </button>
        ))}
      </div>
      {mode === "register" && (
        <>
          <div><Label>Nombre completo</Label><Input value={name} onChange={(e) => setName(e.target.value)} data-testid="cust-name-input" className="mt-1 h-12" placeholder="Martina Álvarez" /></div>
          <div><Label>Teléfono (opcional)</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} data-testid="cust-phone-input" className="mt-1 h-12" placeholder="+54 11 ..." /></div>
        </>
      )}
      <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="cust-email-input" className="mt-1 h-12" placeholder="tu@email.com" /></div>
      <div>
        <Label>Contraseña</Label>
        <div className="relative">
          <Input type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} data-testid="cust-password-input" className="mt-1 h-12 pr-10" />
          <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
            {show ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
      </div>
      <Button onClick={submit} disabled={loading} className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold" data-testid="cust-submit-btn">
        {loading ? "…" : mode === "login" ? "Ingresar" : "Crear cuenta"}
      </Button>
      {mode === "login" && (
        <p className="text-xs text-slate-500 text-center">
          Demo: <code className="font-mono-ld bg-slate-100 px-1.5 py-0.5 rounded">martina@demo.ar</code> / <code className="font-mono-ld bg-slate-100 px-1.5 py-0.5 rounded">demo1234</code>
        </p>
      )}
    </div>
  );
};

const WasherAuth = () => {
  const [washers, setWashers] = useState([]);
  const [washerId, setWasherId] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { getWashersPublic().then((d) => { setWashers(d); if (d[0]) setWasherId(d[0].id); }); }, []);

  const submit = async () => {
    try {
      setLoading(true);
      const data = await loginStaff({ password, washer_id: washerId });
      saveAuth(data.token, data.user);
      toast.success(`¡Hola, ${data.user.name.split(" ")[0]}!`);
    } catch (e) {
      toast.error(errMsg(e, "Error"));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-3" data-testid="washer-auth">
      <p className="text-sm text-slate-600">Acceso staff. Elegí tu perfil e ingresá la clave.</p>
      <div><Label>Tu perfil de lavador</Label>
        <Select value={washerId} onValueChange={setWasherId}>
          <SelectTrigger className="mt-1 h-12" data-testid="washer-profile-select"><SelectValue placeholder="Elegir…" /></SelectTrigger>
          <SelectContent>
            {washers.map((w) => (
              <SelectItem key={w.id} value={w.id} data-testid={`washer-profile-opt-${w.id}`}>{w.name} · {w.zone}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div><Label>Clave de lavador</Label>
        <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="washer-password-input" className="mt-1 h-12" placeholder="Lavador1234" />
      </div>
      <Button onClick={submit} disabled={loading} className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold" data-testid="washer-submit-btn">
        {loading ? "…" : "Ingresar como lavador"}
      </Button>
    </div>
  );
};

const AdminAuth = () => {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    try {
      setLoading(true);
      const data = await loginAdmin({ password });
      saveAuth(data.token, data.user);
      toast.success("Bienvenido, Admin");
    } catch (e) {
      toast.error(errMsg(e, "Clave incorrecta"));
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-3" data-testid="admin-auth">
      <p className="text-sm text-slate-600">Acceso restringido al panel administrativo.</p>
      <div><Label>Clave de administrador</Label>
        <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="admin-password-input" className="mt-1 h-12" placeholder="Admin2026!" />
      </div>
      <Button onClick={submit} disabled={loading} className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white rounded-full font-semibold" data-testid="admin-submit-btn">
        {loading ? "…" : "Ingresar al panel"}
      </Button>
    </div>
  );
};
