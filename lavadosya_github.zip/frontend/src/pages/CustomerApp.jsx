import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { MapPicker } from "@/components/MapPicker";
import {
  listServices, getZones, estimate, createBooking, listBookings,
  getSettingsPublic, rateBooking, validateCoupon, listVehicles,
} from "@/lib/api";
import { fileToDataUrl } from "@/lib/auth";
import { formatARS, formatDate } from "@/lib/format";
import {
  Car, Truck, Bus, MapPin, Calendar, Clock, Sparkles, Check, ArrowRight, History,
  Copy, Landmark, Wallet, MessageCircle, Star, Image as ImageIcon, Tag, X, Warehouse, Repeat,
} from "lucide-react";
import { ChatDialog } from "@/components/ChatDialog";
import { GarageTab } from "@/pages/GarageTab";

const VEHICLE_META = {
  car: { icon: Car, label: "Auto chico / Sedán", desc: "Hatchback, sedán, coupé" },
  suv: { icon: Truck, label: "Pickup mediana / SUV", desc: "Crossover, SUV, pickup mediana" },
  large: { icon: Bus, label: "Vehículo grande / Van", desc: "Pickup 4x4, van, minivan" },
};
const TIMES = ["09:00", "11:00", "14:00", "16:30", "18:00"];

export const CustomerApp = ({ customer }) => (
  <div className="space-y-6" data-testid="customer-root">
    <HeroCustomer customer={customer} />
    <Tabs defaultValue="new" className="w-full">
      <TabsList className="bg-white border border-slate-200 h-11 p-1 rounded-full flex-wrap">
        <TabsTrigger value="new" className="rounded-full px-5 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="tab-new-booking">
          <Sparkles size={14} className="mr-1.5" /> Nueva reserva
        </TabsTrigger>
        <TabsTrigger value="history" className="rounded-full px-5 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="tab-history">
          <History size={14} className="mr-1.5" /> Mis reservas
        </TabsTrigger>
        <TabsTrigger value="garage" className="rounded-full px-5 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="tab-garage">
          <Warehouse size={14} className="mr-1.5" /> Mi Garaje
        </TabsTrigger>
      </TabsList>
      <TabsContent value="new" className="mt-6"><BookingWizard customer={customer} /></TabsContent>
      <TabsContent value="history" className="mt-6"><BookingHistory customer={customer} /></TabsContent>
      <TabsContent value="garage" className="mt-6"><GarageTab /></TabsContent>
    </Tabs>
  </div>
);

const HeroCustomer = ({ customer }) => (
  <Card className="lava-hero-gradient border-0 text-white overflow-hidden relative">
    <div className="absolute inset-0 lava-dots opacity-20" />
    <div className="relative p-6 sm:p-10 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
      <div>
        <Badge className="bg-white/15 text-white border-white/20 hover:bg-white/20 font-semibold">
          Hola, {customer.name.split(" ")[0]} 👋
        </Badge>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-3">
          Reservá tu lavado premium
          <br /><span className="text-sky-200">donde estés en CABA/GBA.</span>
        </h1>
        <p className="mt-3 text-white/80 max-w-xl text-sm sm:text-base">
          El lavador va a tu dirección. Elegís vehículo, servicio, día y horario. Sin complicaciones.
        </p>
      </div>
      <div className="flex items-center gap-2 bg-white/10 border border-white/20 rounded-2xl px-4 py-3">
        <div className="font-mono-ld text-xs text-white/70">LAVADOS DESDE</div>
        <div className="font-display font-extrabold text-3xl" data-testid="promo-price">$20.000</div>
      </div>
    </div>
  </Card>
);

const BookingWizard = ({ customer }) => {
  const [step, setStep] = useState(1);
  const [services, setServices] = useState([]);
  const [zones, setZones] = useState([]);
  const [paymentInfo, setPaymentInfo] = useState(null);
  const [vehicle, setVehicle] = useState("car");
  const [serviceId, setServiceId] = useState("");
  const [address, setAddress] = useState("");
  const [zone, setZone] = useState("");
  const [coords, setCoords] = useState({ lat: null, lng: null });
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");
  const [est, setEst] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("");
  const [proofUrl, setProofUrl] = useState(null);
  const [couponCode, setCouponCode] = useState("");
  const [coupon, setCoupon] = useState(null);
  const [recurrence, setRecurrence] = useState("");
  const [garageVehicles, setGarageVehicles] = useState([]);
  const [garageId, setGarageId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    (async () => {
      const [svcs, zs, s, g] = await Promise.all([listServices(), getZones(), getSettingsPublic(), listVehicles().catch(() => [])]);
      setServices(svcs.filter((x) => x.active !== false));
      setZones(zs);
      setPaymentInfo(s.payment_info);
      setGarageVehicles(g);
    })();
  }, []);

  useEffect(() => { if (serviceId && vehicle) estimate(serviceId, vehicle).then((d) => setEst(d.price)); }, [serviceId, vehicle]);
  useEffect(() => { setCoupon(null); setCouponCode(""); }, [serviceId, vehicle]);

  const service = services.find((s) => s.id === serviceId);
  const finalPrice = coupon ? coupon.final_price : est;
  const canNext =
    (step === 1 && vehicle) ||
    (step === 2 && serviceId) ||
    (step === 3 && address && zone && date && time) ||
    (step === 4 && paymentMethod);

  const submit = async () => {
    try {
      setSubmitting(true);
      const b = await createBooking({
        service_id: serviceId,
        vehicle_type: vehicle,
        address, zone,
        lat: coords.lat, lng: coords.lng,
        date, time,
        notes: notes || null,
        payment_method: paymentMethod,
        payment_proof_url: proofUrl,
        coupon_code: coupon ? coupon.code : null,
        recurrence: recurrence || null,
        vehicle_garage_id: garageId || null,
      });
      toast.success("¡Reserva creada!");
      setSuccess(b);
    } catch (e) {
      toast.error("No pudimos crear la reserva", { description: e?.response?.data?.detail || e.message });
    } finally { setSubmitting(false); }
  };

  if (success) return <SuccessPane booking={success} paymentInfo={paymentInfo} onNew={() => { setSuccess(null); setStep(1); setServiceId(""); setAddress(""); setZone(""); setDate(""); setTime(""); setNotes(""); setPaymentMethod(""); setProofUrl(null); setCoords({ lat: null, lng: null }); setCoupon(null); setCouponCode(""); setRecurrence(""); setGarageId(""); }} />;

  return (
    <div className="grid lg:grid-cols-[1fr_380px] gap-6">
      <Card className="p-5 sm:p-7 bg-white border-slate-100">
        <StepsHeader step={step} />
        {step === 1 && <StepVehicle vehicle={vehicle} setVehicle={setVehicle} garageVehicles={garageVehicles} garageId={garageId} setGarageId={setGarageId} />}
        {step === 2 && <StepService services={services} vehicle={vehicle} serviceId={serviceId} setServiceId={setServiceId} />}
        {step === 3 && (
          <StepLocation
            address={address} setAddress={setAddress}
            zone={zone} setZone={setZone}
            zones={zones} date={date} setDate={setDate}
            time={time} setTime={setTime}
            notes={notes} setNotes={setNotes}
            coords={coords} setCoords={setCoords}
            recurrence={recurrence} setRecurrence={setRecurrence}
          />
        )}
        {step === 4 && (
          <StepPayment
            paymentInfo={paymentInfo}
            paymentMethod={paymentMethod} setPaymentMethod={setPaymentMethod}
            proofUrl={proofUrl} setProofUrl={setProofUrl}
            couponCode={couponCode} setCouponCode={setCouponCode}
            coupon={coupon} setCoupon={setCoupon}
            serviceId={serviceId} vehicle={vehicle}
          />
        )}
        {step === 5 && (
          <StepReview vehicle={vehicle} service={service} address={address} zone={zone} date={date} time={time} notes={notes} paymentMethod={paymentMethod} proofUrl={proofUrl} />
        )}

        <Separator className="my-6" />
        <div className="flex items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1} data-testid="wizard-back-btn">
            Atrás
          </Button>
          {step < 5 ? (
            <Button onClick={() => setStep((s) => s + 1)} disabled={!canNext} data-testid="wizard-next-btn" className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6 rounded-full">
              Siguiente <ArrowRight size={16} className="ml-1" />
            </Button>
          ) : (
            <Button onClick={submit} disabled={submitting} data-testid="booking-submit-btn" className="bg-blue-600 hover:bg-blue-700 text-white h-11 px-6 rounded-full">
              {submitting ? "Enviando…" : "Confirmar reserva"}
            </Button>
          )}
        </div>
      </Card>

      <aside className="space-y-4">
        <Card className="p-5 bg-white border-slate-100 sticky top-24">
          <div className="text-xs font-bold uppercase tracking-widest text-slate-500">Resumen</div>
          <div className="mt-2 flex items-end justify-between">
            <div>
              <div className="text-xs text-slate-500">{coupon ? "Total con descuento" : "Estimado"}</div>
              <div className="font-display text-4xl font-extrabold text-slate-900" data-testid="estimate-price">
                {service && vehicle ? formatARS(finalPrice) : "—"}
              </div>
              {coupon && (
                <div className="text-xs text-emerald-600 font-semibold mt-0.5">
                  −{formatARS(coupon.discount)} con {coupon.code}
                </div>
              )}
            </div>
            <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200">ARS</Badge>
          </div>
          <Separator className="my-4" />
          <div className="space-y-2 text-sm text-slate-600">
            <div className="flex justify-between"><span>Vehículo</span><span className="font-medium text-slate-900">{VEHICLE_META[vehicle]?.label}</span></div>
            <div className="flex justify-between"><span>Servicio</span><span className="font-medium text-slate-900 text-right">{service?.name || "—"}</span></div>
            <div className="flex justify-between"><span>Zona</span><span className="font-medium text-slate-900 text-right">{zone || "—"}</span></div>
            <div className="flex justify-between"><span>Fecha</span><span className="font-medium text-slate-900">{date ? formatDate(date) : "—"}</span></div>
            <div className="flex justify-between"><span>Pago</span><span className="font-medium text-slate-900">{paymentMethod === "transfer" ? "Transferencia" : paymentMethod === "mp" ? "Mercado Pago" : "—"}</span></div>
          </div>
          <div className="mt-4 p-3 rounded-xl bg-blue-50/60 border border-blue-100 text-xs text-blue-900">
            Prototipo privado, sin cobros reales en gateway.
          </div>
        </Card>
      </aside>
    </div>
  );
};

const StepsHeader = ({ step }) => (
  <div className="flex items-center gap-2 flex-wrap mb-6">
    {[1, 2, 3, 4, 5].map((n) => (
      <div key={n} className="flex items-center gap-2">
        <span className={`step-pill ${step >= n ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-500"}`} data-testid={`wizard-step-${n}`}>
          {step > n ? <Check size={14} /> : n}
        </span>
        <span className={`text-[10px] sm:text-xs font-semibold uppercase tracking-wider ${step >= n ? "text-slate-900" : "text-slate-400"}`}>
          {["Vehículo", "Servicio", "Dirección", "Pago", "Confirmar"][n - 1]}
        </span>
        {n < 5 && <span className="h-px w-3 bg-slate-200 hidden sm:block" />}
      </div>
    ))}
  </div>
);

const StepVehicle = ({ vehicle, setVehicle, garageVehicles, garageId, setGarageId }) => {
  const pickFromGarage = (v) => {
    setGarageId(v.id);
    setVehicle(v.type);
  };
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">¿Qué vehículo vamos a lavar?</h2>

      {garageVehicles.length > 0 && (
        <div className="space-y-2" data-testid="wizard-garage-section">
          <Label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Tus vehículos guardados</Label>
          <div className="grid sm:grid-cols-2 gap-2">
            {garageVehicles.map((v) => {
              const active = garageId === v.id;
              return (
                <button key={v.id} onClick={() => pickFromGarage(v)} data-testid={`wizard-garage-${v.id}`}
                  className={`text-left p-3 rounded-xl border-2 flex items-center gap-3 transition-all ${active ? "border-blue-600 bg-blue-50/50" : "border-slate-200 hover:border-blue-200 bg-white"}`}>
                  <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${active ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                    <Car size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm truncate">{v.nickname || `${v.brand} ${v.model}`}</div>
                    <div className="text-xs text-slate-500 truncate">{v.brand} {v.model}{v.color ? ` · ${v.color}` : ""}{v.plate ? ` · ${v.plate.toUpperCase()}` : ""}</div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="text-xs text-slate-400">O elegí el tipo de vehículo manualmente:</div>
        </div>
      )}

      <div className="grid sm:grid-cols-3 gap-3">
        {Object.entries(VEHICLE_META).map(([key, v]) => {
          const Icon = v.icon;
          const active = vehicle === key && !garageId;
          return (
            <button key={key} onClick={() => { setVehicle(key); setGarageId(""); }} data-testid={`vehicle-select-${key}`}
              className={`text-left p-4 rounded-2xl border-2 transition-all ${active ? "border-blue-600 bg-blue-50/50 shadow-md shadow-blue-500/10" : "border-slate-200 hover:border-blue-200 bg-white"}`}>
              <div className={`h-11 w-11 rounded-xl flex items-center justify-center mb-3 ${active ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                <Icon size={22} />
              </div>
              <div className="font-semibold text-slate-900">{v.label}</div>
              <div className="text-xs text-slate-500 mt-1">{v.desc}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

const StepService = ({ services, vehicle, serviceId, setServiceId }) => (
  <div className="space-y-3">
    <h2 className="text-xl font-bold">Elegí el servicio</h2>
    <div className="space-y-3">
      {services.map((s) => {
        const active = serviceId === s.id;
        const mult = vehicle === "car" ? 1 : vehicle === "suv" ? 1.35 : 1.7;
        const price = Math.round((s.base_price * mult) / 100) * 100;
        return (
          <button key={s.id} onClick={() => setServiceId(s.id)} data-testid={`service-select-${s.id}`}
            className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-4 ${active ? "border-blue-600 bg-blue-50/40 shadow-md shadow-blue-500/10" : "border-slate-200 hover:border-blue-200 bg-white"}`}>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-slate-900">{s.name}</span>
                {s.badge && <Badge className="bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-100">{s.badge}</Badge>}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{s.duration_minutes} min · {s.description}</div>
              <ul className="mt-2 grid sm:grid-cols-2 gap-x-3 gap-y-1">
                {s.features.map((f, i) => <li key={i} className="text-xs text-slate-600 flex items-center gap-1.5"><Check size={12} className="text-blue-600" /> {f}</li>)}
              </ul>
            </div>
            <div className="text-right shrink-0">
              <div className="text-xs text-slate-500">Precio</div>
              <div className="font-display font-extrabold text-2xl text-slate-900">{formatARS(price)}</div>
            </div>
          </button>
        );
      })}
    </div>
  </div>
);

const StepLocation = ({ address, setAddress, zone, setZone, zones, date, setDate, time, setTime, notes, setNotes, coords, setCoords, recurrence, setRecurrence }) => (
  <div className="space-y-4">
    <h2 className="text-xl font-bold">Dirección y horario</h2>
    <div>
      <Label>Dirección exacta del vehículo</Label>
      <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Av. del Libertador 2450" data-testid="address-input" className="mt-1 h-12" />
    </div>
    <div>
      <Label>Zona / Barrio</Label>
      <Select value={zone} onValueChange={setZone}>
        <SelectTrigger className="mt-1 h-12" data-testid="zone-select"><SelectValue placeholder="Elegí la zona" /></SelectTrigger>
        <SelectContent>{zones.map((z) => <SelectItem key={z} value={z} data-testid={`zone-opt-${z}`}>{z}</SelectItem>)}</SelectContent>
      </Select>
    </div>
    <div>
      <Label>Marcá en el mapa</Label>
      <p className="text-xs text-slate-500 mb-2">Tocá el mapa o arrastrá el marcador para ubicar el vehículo con precisión.</p>
      <MapPicker lat={coords.lat} lng={coords.lng} onChange={setCoords} />
      {coords.lat && (
        <div className="text-xs text-slate-500 mt-1 font-mono-ld">
          📍 {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
        </div>
      )}
    </div>
    <div className="grid sm:grid-cols-2 gap-3">
      <div><Label>Fecha</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} data-testid="date-input" className="mt-1 h-12" min={new Date().toISOString().slice(0, 10)} /></div>
      <div>
        <Label>Horario preferido</Label>
        <Select value={time} onValueChange={setTime}>
          <SelectTrigger className="mt-1 h-12" data-testid="time-select"><SelectValue placeholder="Elegí el horario" /></SelectTrigger>
          <SelectContent>{TIMES.map((t) => <SelectItem key={t} value={t} data-testid={`time-opt-${t}`}>{t} hs</SelectItem>)}</SelectContent>
        </Select>
      </div>
    </div>

    {/* Recurrence */}
    <div className="rounded-2xl p-4 bg-blue-50/40 border border-blue-100" data-testid="recurrence-section">
      <Label className="flex items-center gap-1.5 text-blue-900"><Repeat size={14} /> Programación recurrente</Label>
      <p className="text-xs text-blue-800/70 mt-0.5 mb-2">Agendamos los próximos 4 lavados automáticamente a partir de la fecha elegida.</p>
      <div className="grid sm:grid-cols-3 gap-2">
        {[
          { v: "", label: "Solo esta vez", desc: "1 lavado" },
          { v: "weekly", label: "Semanal", desc: "Cada 7 días" },
          { v: "biweekly", label: "Quincenal", desc: "Cada 14 días" },
        ].map((o) => {
          const active = recurrence === o.v;
          return (
            <button key={o.v || "once"} onClick={() => setRecurrence(o.v)} data-testid={`recurrence-${o.v || "once"}`}
              className={`text-left p-3 rounded-xl border-2 transition-all ${active ? "border-blue-600 bg-white shadow-md shadow-blue-500/10" : "border-transparent bg-white hover:border-blue-200"}`}>
              <div className="font-semibold text-sm text-slate-900">{o.label}</div>
              <div className="text-xs text-slate-500">{o.desc}</div>
            </button>
          );
        })}
      </div>
    </div>

    <div>
      <Label>Notas para el lavador (opcional)</Label>
      <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Portón negro, timbre B, llamar al llegar" data-testid="notes-input" className="mt-1 min-h-[72px]" />
    </div>
  </div>
);

const StepPayment = ({ paymentInfo, paymentMethod, setPaymentMethod, proofUrl, setProofUrl, couponCode, setCouponCode, coupon, setCoupon, serviceId, vehicle }) => {
  const copy = (val) => { navigator.clipboard.writeText(val); toast.success("¡Copiado!", { description: val }); };
  const onFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 3 * 1024 * 1024) return toast.error("Imagen demasiado grande (máx 3MB)");
    const url = await fileToDataUrl(f);
    setProofUrl(url);
    toast.success("Comprobante cargado");
  };
  const [validating, setValidating] = useState(false);
  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    try {
      setValidating(true);
      const data = await validateCoupon(couponCode, serviceId, vehicle);
      setCoupon(data);
      toast.success(`Cupón aplicado: -${data.kind === "percent" ? data.value + "%" : "$" + data.value}`, { description: data.description });
    } catch (e) {
      setCoupon(null);
      toast.error(e?.response?.data?.detail || "Cupón inválido");
    } finally { setValidating(false); }
  };
  const removeCoupon = () => { setCoupon(null); setCouponCode(""); };

  if (!paymentInfo) return <div>Cargando…</div>;

  return (
    <div className="space-y-4" data-testid="payment-step">
      <h2 className="text-xl font-bold">Datos de pago</h2>
      <p className="text-sm text-slate-500">Elegí tu método, copiá los datos y subí la captura del comprobante.</p>

      {/* Coupon */}
      <Card className="p-3 bg-amber-50/60 border-amber-200">
        <Label className="flex items-center gap-1.5 text-amber-900"><Tag size={14} /> ¿Tenés un cupón?</Label>
        {coupon ? (
          <div className="mt-2 flex items-center justify-between gap-2 bg-white rounded-xl px-3 py-2 border border-emerald-200">
            <div>
              <div className="font-mono-ld font-bold text-emerald-700" data-testid="coupon-applied">{coupon.code}</div>
              <div className="text-xs text-emerald-600">
                {coupon.kind === "percent" ? `${coupon.value}% OFF` : `−${formatARS(coupon.value)}`} · Ahorrás {formatARS(coupon.discount)}
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={removeCoupon} data-testid="coupon-remove">
              <X size={14} />
            </Button>
          </div>
        ) : (
          <div className="mt-2 flex items-center gap-2">
            <Input value={couponCode} onChange={(e) => setCouponCode(e.target.value.toUpperCase())} placeholder="BIENVENIDA10" data-testid="coupon-input" className="h-11 uppercase font-mono-ld" />
            <Button onClick={applyCoupon} disabled={validating || !couponCode} data-testid="coupon-apply-btn" className="h-11 bg-amber-500 hover:bg-amber-600 text-white rounded-full">
              {validating ? "…" : "Aplicar"}
            </Button>
          </div>
        )}
      </Card>

      <div className="grid sm:grid-cols-2 gap-3">
        <button onClick={() => setPaymentMethod("transfer")} data-testid="pay-method-transfer"
          className={`text-left p-4 rounded-2xl border-2 transition-all ${paymentMethod === "transfer" ? "border-blue-600 bg-blue-50/40 shadow-md shadow-blue-500/10" : "border-slate-200 hover:border-blue-200"}`}>
          <div className="h-10 w-10 rounded-xl bg-blue-600 text-white flex items-center justify-center"><Landmark size={18} /></div>
          <div className="mt-2 font-semibold">Transferencia bancaria</div>
          <div className="text-xs text-slate-500">BBVA · CBU / Alias</div>
        </button>
        <button onClick={() => setPaymentMethod("mp")} data-testid="pay-method-mp"
          className={`text-left p-4 rounded-2xl border-2 transition-all ${paymentMethod === "mp" ? "border-blue-600 bg-blue-50/40 shadow-md shadow-blue-500/10" : "border-slate-200 hover:border-blue-200"}`}>
          <div className="h-10 w-10 rounded-xl bg-sky-500 text-white flex items-center justify-center"><Wallet size={18} /></div>
          <div className="mt-2 font-semibold">Mercado Pago</div>
          <div className="text-xs text-slate-500">Alias Lavadosya.mp</div>
        </button>
      </div>

      {paymentMethod === "transfer" && (
        <Card className="p-4 bg-slate-50/60 border-slate-200">
          <div className="font-semibold mb-2 flex items-center gap-2"><Landmark size={16} className="text-blue-600" /> Banco BBVA</div>
          <PaymentRow label="CBU" value={paymentInfo.bank.cbu} onCopy={copy} testid="copy-cbu" />
          <PaymentRow label="Alias" value={paymentInfo.bank.alias} onCopy={copy} testid="copy-alias-bank" />
          <PaymentRow label="Titular" value={paymentInfo.bank.holder} />
          <PaymentRow label="CUIT" value={paymentInfo.bank.cuit} onCopy={copy} testid="copy-cuit" />
        </Card>
      )}
      {paymentMethod === "mp" && (
        <Card className="p-4 bg-slate-50/60 border-slate-200">
          <div className="font-semibold mb-2 flex items-center gap-2"><Wallet size={16} className="text-sky-500" /> Mercado Pago</div>
          <PaymentRow label="Alias MP" value={paymentInfo.mp.alias} onCopy={copy} testid="copy-alias-mp" />
          <PaymentRow label="Titular" value={paymentInfo.mp.holder} />
          <PaymentRow label="CUIT" value={paymentInfo.mp.cuit} onCopy={copy} />
        </Card>
      )}

      {paymentMethod && (
        <div className="space-y-2">
          <Label>Subí la captura del comprobante (opcional)</Label>
          <div className="flex items-center gap-3">
            <label className="inline-flex items-center gap-2 h-12 px-4 rounded-xl border-2 border-dashed border-slate-300 bg-white cursor-pointer hover:border-blue-400 transition-colors" data-testid="proof-upload-label">
              <ImageIcon size={16} />
              <span className="text-sm font-medium">{proofUrl ? "Cambiar imagen" : "Subir comprobante"}</span>
              <input type="file" accept="image/*" onChange={onFile} className="hidden" data-testid="proof-upload-input" />
            </label>
            {proofUrl && <img src={proofUrl} alt="comprobante" className="h-12 w-12 rounded-lg object-cover border border-slate-200" />}
          </div>
        </div>
      )}
    </div>
  );
};

const PaymentRow = ({ label, value, onCopy, testid }) => (
  <div className="flex items-center justify-between gap-2 py-1.5">
    <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider w-20">{label}</div>
    <div className="font-mono-ld text-sm text-slate-900 flex-1 truncate">{value}</div>
    {onCopy && (
      <Button size="sm" variant="outline" onClick={() => onCopy(value)} data-testid={testid} className="h-8 rounded-full">
        <Copy size={12} className="mr-1" /> Copiar
      </Button>
    )}
  </div>
);

const StepReview = ({ vehicle, service, address, zone, date, time, notes, paymentMethod, proofUrl }) => (
  <div className="space-y-4">
    <h2 className="text-xl font-bold">Confirmá tu reserva</h2>
    <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-5 space-y-3">
      <Row icon={Car} label="Vehículo" value={VEHICLE_META[vehicle].label} />
      <Row icon={Sparkles} label="Servicio" value={service?.name || "–"} />
      <Row icon={MapPin} label="Dirección" value={`${address} · ${zone}`} />
      <Row icon={Calendar} label="Fecha" value={formatDate(date)} />
      <Row icon={Clock} label="Horario" value={`${time} hs`} />
      <Row icon={Wallet} label="Pago" value={paymentMethod === "transfer" ? "Transferencia BBVA" : "Mercado Pago"} />
      {proofUrl && <div className="pl-11"><img src={proofUrl} alt="comprobante" className="h-24 rounded-lg border border-slate-200" /></div>}
      {notes && <Row icon={Check} label="Notas" value={notes} />}
    </div>
  </div>
);

const Row = ({ icon: Icon, label, value }) => (
  <div className="flex items-start gap-3">
    <div className="h-8 w-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0"><Icon size={16} /></div>
    <div className="flex-1">
      <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider">{label}</div>
      <div className="font-semibold text-slate-900">{value}</div>
    </div>
  </div>
);

const SuccessPane = ({ booking, paymentInfo, onNew }) => {
  const msg = useMemo(() => {
    const lines = [
      "🚿 *Nueva reserva LAVADOSYA!*",
      "",
      `*Cliente:* ${booking.customer_name}`,
      `*Vehículo:* ${booking.vehicle_label}`,
      `*Servicio:* ${booking.service_name}`,
      `*Ubicación:* ${booking.address} · ${booking.zone}`,
      booking.lat && booking.lng ? `*Mapa:* https://maps.google.com/?q=${booking.lat},${booking.lng}` : null,
      `*Fecha:* ${formatDate(booking.date)} · ${booking.time} hs`,
      `*Precio:* ${formatARS(booking.price)}`,
      `*Pago:* ${booking.payment_method === "transfer" ? "Transferencia BBVA" : "Mercado Pago"} · ${booking.payment_status === "enviado" ? "comprobante enviado" : "pendiente"}`,
      booking.notes ? `*Notas:* ${booking.notes}` : null,
    ].filter(Boolean);
    return encodeURIComponent(lines.join("\n"));
  }, [booking]);

  const waUrl = `https://wa.me/${paymentInfo?.whatsapp || "5491162769702"}?text=${msg}`;

  return (
    <Card className="p-8 bg-white border-slate-100 text-center max-w-xl mx-auto" data-testid="booking-success">
      <div className="h-16 w-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
        <Check size={32} />
      </div>
      <h2 className="font-display font-extrabold text-3xl mt-4">¡Reserva confirmada!</h2>
      <p className="text-slate-600 mt-2">Te confirmamos los detalles por WhatsApp.</p>
      <div className="mt-6 rounded-2xl bg-slate-50 border border-slate-200 p-4 text-left space-y-1 text-sm">
        <div><span className="text-slate-500">Servicio:</span> <span className="font-semibold">{booking.service_name}</span></div>
        <div><span className="text-slate-500">Total:</span> <span className="font-display font-bold">{formatARS(booking.price)}</span></div>
        <div><span className="text-slate-500">Estado:</span> <StatusBadge status={booking.status} /></div>
      </div>
      <a href={waUrl} target="_blank" rel="noreferrer" data-testid="whatsapp-btn">
        <Button className="mt-6 w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full font-semibold">
          <MessageCircle size={18} className="mr-2" /> Enviar pedido por WhatsApp
        </Button>
      </a>
      <Button onClick={onNew} variant="outline" className="mt-3 w-full h-11 rounded-full" data-testid="new-booking-btn">
        Hacer otra reserva
      </Button>
    </Card>
  );
};

// -------- HISTORY --------
const BookingHistory = ({ customer }) => {
  const [bookings, setBookings] = useState([]);
  const [filter, setFilter] = useState("todos");
  const [rateBk, setRateBk] = useState(null);
  const [chatBk, setChatBk] = useState(null);

  const load = async () => {
    const data = await listBookings();
    setBookings(data);
  };
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []);

  const filtered = useMemo(() => {
    if (filter === "todos") return bookings;
    if (filter === "activos") return bookings.filter((b) => ["aceptado", "en_camino", "en_progreso"].includes(b.status));
    if (filter === "completados") return bookings.filter((b) => b.status === "completado");
    if (filter === "pendientes") return bookings.filter((b) => b.status === "pendiente");
    return bookings;
  }, [bookings, filter]);

  return (
    <div className="space-y-4" data-testid="customer-history">
      <div className="flex items-center gap-2 flex-wrap">
        {["todos", "activos", "pendientes", "completados"].map((f) => (
          <button key={f} onClick={() => setFilter(f)} data-testid={`history-filter-${f}`}
            className={`h-9 px-4 rounded-full text-sm font-semibold transition-all border ${filter === f ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"}`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <Card className="p-10 text-center bg-white border-dashed border-slate-200"><p className="text-slate-500">Todavía no tenés reservas acá.</p></Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((b) => <HistoryCard key={b.id} b={b} onRate={() => setRateBk(b)} onChat={() => setChatBk(b)} />)}
        </div>
      )}
      {rateBk && <RateDialog booking={rateBk} onClose={() => { setRateBk(null); load(); }} />}
      {chatBk && <ChatDialog booking={chatBk} me={customer} onClose={() => setChatBk(null)} />}
    </div>
  );
};

const HistoryCard = ({ b, onRate, onChat }) => {
  const canChat = b.washer_id && ["aceptado", "en_camino", "en_progreso"].includes(b.status);
  const washerLat = b.washer_lat || (b.status === "en_camino" || b.status === "en_progreso" ? b.lat : null);
  const washerLng = b.washer_lng || (b.status === "en_camino" || b.status === "en_progreso" ? b.lng : null);
  return (
    <Card className="p-5 bg-white border-slate-100 hover:shadow-lg transition-shadow" data-testid={`history-item-${b.id}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-display font-bold text-lg text-slate-900 flex items-center gap-2">
            {b.service_name}
            {b.recurrence && (
              <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-50 text-[10px]">
                <Repeat size={10} className="mr-0.5" /> {b.recurrence === "weekly" ? "Semanal" : "Quincenal"}
              </Badge>
            )}
            {b.parent_booking_id && (
              <Badge className="bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-100 text-[10px]">Recurrente</Badge>
            )}
          </div>
          <div className="text-xs text-slate-500">{b.vehicle_label}</div>
        </div>
        <StatusBadge status={b.status} />
      </div>
      <Separator className="my-3" />
      <div className="space-y-1.5 text-sm text-slate-700">
        <div className="flex items-center gap-2"><MapPin size={14} className="text-blue-600" /> {b.address} · {b.zone}</div>
        <div className="flex items-center gap-2"><Calendar size={14} className="text-blue-600" /> {formatDate(b.date)} · <Clock size={14} className="text-blue-600" /> {b.time} hs</div>
        {b.washer_name && <div className="text-xs text-slate-500">Lavador: <span className="font-semibold text-slate-900">{b.washer_name}</span></div>}
        {b.payment_status && (
          <div className="text-xs">
            <span className="text-slate-500">Pago:</span>{" "}
            <span className={`font-semibold ${b.payment_status === "verificado" ? "text-emerald-600" : b.payment_status === "rechazado" ? "text-rose-600" : "text-amber-600"}`}>
              {b.payment_status}
            </span>
          </div>
        )}
      </div>

      {["aceptado", "en_camino", "en_progreso"].includes(b.status) && b.lat && b.lng && (
        <div className="mt-3">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center justify-between">
            <span>Seguimiento en vivo</span>
            {b.washer_location_updated_at && <span className="text-emerald-600 flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> En vivo</span>}
          </div>
          <MapPicker lat={b.lat} lng={b.lng} readOnly height={160} washerLat={washerLat} washerLng={washerLng} />
        </div>
      )}

      {b.status === "completado" && (b.before_photo_url || b.after_photo_url) && (
        <div className="mt-3 grid grid-cols-2 gap-2">
          {b.before_photo_url && <div><div className="text-[10px] uppercase font-bold text-slate-500">Antes</div><img src={b.before_photo_url} alt="antes" className="rounded-lg border border-slate-200 w-full h-28 object-cover" /></div>}
          {b.after_photo_url && <div><div className="text-[10px] uppercase font-bold text-slate-500">Después</div><img src={b.after_photo_url} alt="después" className="rounded-lg border border-slate-200 w-full h-28 object-cover" /></div>}
        </div>
      )}

      {b.rating && (
        <div className="mt-3 flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((n) => <Star key={n} size={16} className={n <= b.rating ? "fill-amber-400 text-amber-400" : "text-slate-300"} />)}
          {b.rating_comment && <span className="text-xs text-slate-600 ml-2">“{b.rating_comment}”</span>}
        </div>
      )}

      <div className="mt-3 flex items-center justify-between">
        <div className="text-xs text-slate-500">Total</div>
        <div className="font-display font-extrabold text-xl">{formatARS(b.price)}</div>
      </div>

      <div className="mt-3 flex items-center gap-2">
        {canChat && (
          <Button onClick={onChat} variant="outline" className="flex-1 rounded-full h-10 border-blue-200 hover:bg-blue-50" data-testid={`chat-btn-${b.id}`}>
            <MessageCircle size={14} className="mr-1.5" /> Chat con lavador
          </Button>
        )}
        {b.status === "completado" && !b.rating && (
          <Button onClick={onRate} data-testid={`rate-btn-${b.id}`} className="flex-1 h-10 bg-amber-500 hover:bg-amber-600 text-white rounded-full">
            <Star size={16} className="mr-1.5" /> Calificar
          </Button>
        )}
      </div>
    </Card>
  );
};

const RateDialog = ({ booking, onClose }) => {
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    try {
      setLoading(true);
      await rateBooking(booking.id, { rating: stars, comment });
      toast.success("¡Gracias por tu calificación!");
      onClose();
    } catch (e) { toast.error("Error al enviar"); } finally { setLoading(false); }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent data-testid="rate-dialog">
        <DialogHeader><DialogTitle>Calificá tu lavado</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center gap-2 justify-center py-4">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} onClick={() => setStars(n)} data-testid={`star-${n}`} className="transition-transform hover:scale-110">
                <Star size={36} className={n <= stars ? "fill-amber-400 text-amber-400" : "text-slate-300"} />
              </button>
            ))}
          </div>
          <Textarea placeholder="Dejá un comentario (opcional)" value={comment} onChange={(e) => setComment(e.target.value)} data-testid="rate-comment-input" />
          <Button onClick={submit} disabled={loading} className="w-full h-12 bg-amber-500 hover:bg-amber-600 text-white rounded-full font-semibold" data-testid="rate-submit-btn">
            {loading ? "Enviando…" : "Enviar calificación"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
