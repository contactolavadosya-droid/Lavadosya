import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { listVehicles, createVehicle, updateVehicle, deleteVehicle } from "@/lib/api";
import { Car, Truck, Bus, Plus, Pencil, Trash2 } from "lucide-react";

const TYPE_META = {
  car: { icon: Car, label: "Auto chico / Sedán" },
  suv: { icon: Truck, label: "Pickup mediana / SUV" },
  large: { icon: Bus, label: "Vehículo grande / Van" },
};

const empty = { type: "car", brand: "", model: "", color: "", plate: "", nickname: "" };

export const GarageTab = () => {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const load = () => listVehicles().then(setItems);
  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (v) => { setEditing(v); setForm({ ...empty, ...v }); setOpen(true); };

  const submit = async () => {
    if (!form.brand || !form.model) return toast.error("Completá marca y modelo");
    try {
      if (editing) await updateVehicle(editing.id, form);
      else await createVehicle(form);
      toast.success(editing ? "Vehículo actualizado" : "Vehículo guardado");
      setOpen(false); load();
    } catch { toast.error("Error al guardar"); }
  };
  const remove = async (id) => { try { await deleteVehicle(id); toast.success("Eliminado"); load(); } catch { toast.error("Error"); } };

  return (
    <div className="space-y-4" data-testid="garage-root">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-display font-extrabold text-2xl">Mi Garaje</h2>
          <p className="text-sm text-slate-500">Guardá tus autos para reservar más rápido las próximas veces.</p>
        </div>
        <Button onClick={openCreate} className="bg-blue-600 hover:bg-blue-700 text-white rounded-full h-11 px-5" data-testid="garage-add-btn">
          <Plus size={16} className="mr-1.5" /> Agregar vehículo
        </Button>
      </div>

      {items.length === 0 ? (
        <Card className="p-10 text-center bg-white border-dashed border-slate-200">
          <p className="text-slate-500">Todavía no agregaste vehículos.</p>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((v) => {
            const Icon = TYPE_META[v.type]?.icon || Car;
            return (
              <Card key={v.id} className="p-5 bg-white border-slate-100 hover:shadow-lg transition-shadow" data-testid={`garage-item-${v.id}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="h-11 w-11 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                    <Icon size={20} />
                  </div>
                  <Badge className="bg-slate-100 text-slate-700 border-slate-200">{TYPE_META[v.type]?.label}</Badge>
                </div>
                <div className="mt-3 font-display font-bold text-lg">
                  {v.nickname || `${v.brand} ${v.model}`}
                </div>
                <div className="text-sm text-slate-600">{v.brand} {v.model}{v.color ? ` · ${v.color}` : ""}</div>
                {v.plate && (
                  <div className="mt-2 inline-block px-2.5 py-1 rounded-md bg-slate-900 text-white font-mono-ld text-xs tracking-widest">
                    {v.plate.toUpperCase()}
                  </div>
                )}
                <Separator className="my-3" />
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(v)} data-testid={`garage-edit-${v.id}`}><Pencil size={14} /></Button>
                  <Button variant="ghost" size="icon" onClick={() => remove(v.id)} data-testid={`garage-delete-${v.id}`}><Trash2 size={14} className="text-rose-600" /></Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent data-testid="garage-dialog">
          <DialogHeader><DialogTitle>{editing ? "Editar vehículo" : "Nuevo vehículo"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Tipo de vehículo</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger data-testid="garage-type-select"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="car">Auto chico / Sedán</SelectItem>
                  <SelectItem value="suv">Pickup mediana / SUV</SelectItem>
                  <SelectItem value="large">Vehículo grande / Van</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Marca</Label><Input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} data-testid="garage-brand" placeholder="Volkswagen" /></div>
              <div><Label>Modelo</Label><Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} data-testid="garage-model" placeholder="Golf" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Color</Label><Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} data-testid="garage-color" placeholder="Blanco" /></div>
              <div><Label>Patente</Label><Input value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value.toUpperCase() })} data-testid="garage-plate" placeholder="AB123CD" className="uppercase font-mono-ld" /></div>
            </div>
            <div><Label>Alias (opcional)</Label><Input value={form.nickname} onChange={(e) => setForm({ ...form, nickname: e.target.value })} data-testid="garage-nickname" placeholder="El de la ciudad" /></div>
          </div>
          <DialogFooter>
            <Button onClick={submit} data-testid="garage-submit-btn" className="bg-blue-600 hover:bg-blue-700 text-white">Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
