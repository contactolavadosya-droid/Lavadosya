import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/StatusBadge";
import {
  getStats, listBookings, listServices, listUsers,
  assignBookingWasher, updateBookingStatus, updateService, createService, deleteService,
  createUser, deleteUser, deleteBooking, changePasswords, getSettings, updatePaymentInfo,
  setPaymentStatus, listCoupons, createCoupon, updateCoupon, deleteCoupon,
  getMonthlyReport, monthlyReportUrl,
} from "@/lib/api";
import { formatARS, formatDate } from "@/lib/format";
import { DollarSign, Users, CheckCircle2, Star, UserPlus, Trash2, Pencil, Plus, KeyRound, Settings as SettingsIcon, Tag, Check, X, Receipt, FileText, FileSpreadsheet, Trophy } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const COLORS = ["#0052FF", "#0EA5E9", "#8B5CF6", "#F59E0B", "#10B981", "#EF4444"];

export const AdminApp = () => {
  const [washers, setWashers] = useState([]);
  useEffect(() => { listUsers("washer").then(setWashers); }, []);

  return (
    <div className="space-y-6" data-testid="admin-root">
      <AdminHero />
      <Tabs defaultValue="bookings" className="w-full">
        <TabsList className="bg-white border border-slate-200 h-11 p-1 rounded-full flex-wrap">
          <TabsTrigger value="bookings" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-bookings">Reservas</TabsTrigger>
          <TabsTrigger value="payments" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-payments">Pagos</TabsTrigger>
          <TabsTrigger value="users" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-users">Usuarios</TabsTrigger>
          <TabsTrigger value="services" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-services">Precios</TabsTrigger>
          <TabsTrigger value="coupons" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-coupons">Cupones</TabsTrigger>
          <TabsTrigger value="stats" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-stats">Stats</TabsTrigger>
          <TabsTrigger value="settings" className="rounded-full px-4 h-9 data-[state=active]:bg-blue-600 data-[state=active]:text-white" data-testid="admin-tab-settings">Ajustes</TabsTrigger>
        </TabsList>
        <TabsContent value="bookings" className="mt-6"><BookingsTab washers={washers} /></TabsContent>
        <TabsContent value="payments" className="mt-6"><PaymentsTab /></TabsContent>
        <TabsContent value="users" className="mt-6"><UsersTab /></TabsContent>
        <TabsContent value="services" className="mt-6"><ServicesTab /></TabsContent>
        <TabsContent value="coupons" className="mt-6"><CouponsTab /></TabsContent>
        <TabsContent value="stats" className="mt-6"><StatsTab /></TabsContent>
        <TabsContent value="settings" className="mt-6"><SettingsTab /></TabsContent>
      </Tabs>
    </div>
  );
};

const AdminHero = () => {
  const [stats, setStats] = useState(null);
  useEffect(() => { getStats().then(setStats); const t = setInterval(() => getStats().then(setStats), 6000); return () => clearInterval(t); }, []);
  return (
    <Card className="p-6 sm:p-8 bg-white border-slate-100">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <Badge className="bg-slate-900 text-white hover:bg-slate-900">Panel de control</Badge>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold mt-2">Centro de Administración</h1>
          <div className="text-sm text-slate-500 mt-1">Vista general del marketplace LAVADOSYA!</div>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        <KPI icon={DollarSign} label="Facturación" value={stats ? formatARS(stats.revenue_total) : "—"} tint="blue" testid="kpi-revenue" />
        <KPI icon={CheckCircle2} label="Servicios realizados" value={stats?.bookings_completed ?? "—"} tint="emerald" testid="kpi-completed" />
        <KPI icon={Users} label="Lavadores" value={stats?.washers_total ?? "—"} tint="sky" testid="kpi-washers" />
        <KPI icon={Star} label="Rating promedio" value={stats?.avg_rating ? `${stats.avg_rating} ⭐` : "—"} tint="amber" testid="kpi-rating" />
      </div>
    </Card>
  );
};

const KPI = ({ icon: Icon, label, value, tint, testid }) => {
  const tints = { blue: "bg-blue-50 text-blue-600", emerald: "bg-emerald-50 text-emerald-600", sky: "bg-sky-50 text-sky-600", amber: "bg-amber-50 text-amber-600" };
  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50/40 p-4" data-testid={testid}>
      <div className={`h-10 w-10 rounded-xl ${tints[tint]} flex items-center justify-center mb-3`}><Icon size={18} /></div>
      <div className="font-display font-extrabold text-2xl text-slate-900">{value}</div>
      <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-0.5">{label}</div>
    </div>
  );
};

const BookingsTab = ({ washers }) => {
  const [bookings, setBookings] = useState([]);
  const load = () => listBookings().then(setBookings);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, []);

  const assign = async (id, w) => { try { await assignBookingWasher(id, w); toast.success("Lavador asignado"); load(); } catch { toast.error("Error"); } };
  const setStatus = async (id, s) => { try { await updateBookingStatus(id, s); toast.success("Estado actualizado"); load(); } catch { toast.error("Error"); } };
  const remove = async (id) => { try { await deleteBooking(id); toast.success("Eliminada"); load(); } catch { toast.error("Error"); } };

  return (
    <Card className="bg-white border-slate-100 overflow-hidden">
      <div className="p-5 flex items-center justify-between">
        <h3 className="font-bold text-lg">Gestión de reservas</h3>
        <span className="text-xs text-slate-500">{bookings.length} reservas</span>
      </div>
      <Separator />
      <div className="overflow-x-auto">
        <Table>
          <TableHeader><TableRow><TableHead>Cliente / Servicio</TableHead><TableHead>Fecha</TableHead><TableHead>Zona</TableHead><TableHead>Lavador</TableHead><TableHead>Estado</TableHead><TableHead>Pago</TableHead><TableHead className="text-right">Precio</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {bookings.map((b) => (
              <TableRow key={b.id} data-testid={`admin-booking-${b.id}`}>
                <TableCell><div className="font-semibold">{b.customer_name}</div><div className="text-xs text-slate-500">{b.service_name} · {b.vehicle_label}</div></TableCell>
                <TableCell className="text-sm">{formatDate(b.date)}<div className="text-xs text-slate-500">{b.time} hs</div></TableCell>
                <TableCell className="text-xs">{b.zone}</TableCell>
                <TableCell>
                  <Select value={b.washer_id || ""} onValueChange={(v) => assign(b.id, v)}>
                    <SelectTrigger className="h-9 w-[180px]" data-testid={`admin-assign-${b.id}`}><SelectValue placeholder="Asignar…" /></SelectTrigger>
                    <SelectContent>{washers.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Select value={b.status} onValueChange={(v) => setStatus(b.id, v)}>
                    <SelectTrigger className="h-9 w-[150px]" data-testid={`admin-status-${b.id}`}><SelectValue /></SelectTrigger>
                    <SelectContent>{["pendiente", "aceptado", "en_camino", "en_progreso", "completado", "cancelado"].map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </TableCell>
                <TableCell className="text-xs">
                  {b.payment_method && <Badge variant="outline" className="text-xs">{b.payment_method === "transfer" ? "Transf." : "MP"}</Badge>}
                  <div className="text-[10px] text-slate-500 mt-0.5">{b.payment_status}</div>
                </TableCell>
                <TableCell className="text-right font-display font-bold">{formatARS(b.price)}</TableCell>
                <TableCell className="text-right"><Button size="icon" variant="ghost" onClick={() => remove(b.id)} data-testid={`admin-booking-delete-${b.id}`}><Trash2 size={16} className="text-rose-600" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

const UsersTab = () => {
  const [users, setUsers] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "customer", phone: "", zone: "" });

  const load = () => listUsers().then(setUsers);
  useEffect(() => { load(); }, []);

  const submit = async () => {
    if (!form.name || !form.email) return toast.error("Completá nombre e email");
    try { await createUser(form); toast.success("Usuario creado"); setOpen(false); setForm({ name: "", email: "", role: "customer", phone: "", zone: "" }); load(); }
    catch { toast.error("Error"); }
  };
  const remove = async (id) => { try { await deleteUser(id); toast.success("Eliminado"); load(); } catch { toast.error("Error"); } };

  return (
    <Card className="bg-white border-slate-100 overflow-hidden">
      <div className="p-5 flex items-center justify-between">
        <h3 className="font-bold text-lg">Gestión de usuarios</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full" data-testid="admin-user-add-btn"><UserPlus size={16} className="mr-1.5" /> Nuevo usuario</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nuevo usuario</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Nombre</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="admin-user-name" /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} data-testid="admin-user-email" /></div>
              <div><Label>Rol</Label>
                <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                  <SelectTrigger data-testid="admin-user-role"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="customer">Cliente</SelectItem><SelectItem value="washer">Lavador</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Teléfono</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div><Label>Zona</Label><Input value={form.zone} onChange={(e) => setForm({ ...form, zone: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={submit} data-testid="admin-user-submit" className="bg-blue-600 hover:bg-blue-700">Crear</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Separator />
      <div className="overflow-x-auto">
        <Table>
          <TableHeader><TableRow><TableHead>Nombre</TableHead><TableHead>Email</TableHead><TableHead>Rol</TableHead><TableHead>Zona</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {users.map((u) => (
              <TableRow key={u.id} data-testid={`admin-user-${u.id}`}>
                <TableCell className="font-semibold">{u.name}</TableCell>
                <TableCell className="text-sm text-slate-600">{u.email}</TableCell>
                <TableCell><Badge className={u.role === "washer" ? "bg-sky-50 text-sky-700 border-sky-200" : "bg-blue-50 text-blue-700 border-blue-200"}>{u.role}</Badge></TableCell>
                <TableCell className="text-xs">{u.zone || "—"}</TableCell>
                <TableCell className="text-right"><Button size="icon" variant="ghost" onClick={() => remove(u.id)} data-testid={`admin-user-delete-${u.id}`}><Trash2 size={16} className="text-rose-600" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

const ServicesTab = () => {
  const [services, setServices] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", description: "", duration_minutes: 60, base_price: 20000, badge: "", features: "" });

  const load = () => listServices().then(setServices);
  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm({ name: "", description: "", duration_minutes: 60, base_price: 20000, badge: "", features: "" }); setOpen(true); };
  const openEdit = (s) => { setEditing(s); setForm({ ...s, features: (s.features || []).join("\n") }); setOpen(true); };

  const submit = async () => {
    const payload = { ...form, duration_minutes: Number(form.duration_minutes), base_price: Number(form.base_price), features: form.features.split("\n").map((f) => f.trim()).filter(Boolean) };
    try { if (editing) await updateService(editing.id, payload); else await createService(payload); toast.success("Guardado"); setOpen(false); load(); }
    catch { toast.error("Error"); }
  };
  const remove = async (id) => { try { await deleteService(id); toast.success("Eliminado"); load(); } catch { toast.error("Error"); } };

  const quickEditPrice = async (s, newPrice) => {
    try { await updateService(s.id, { base_price: Number(newPrice) }); toast.success("Precio actualizado"); load(); } catch { toast.error("Error"); }
  };

  return (
    <Card className="bg-white border-slate-100 overflow-hidden">
      <div className="p-5 flex items-center justify-between">
        <h3 className="font-bold text-lg">Precios y servicios (precio base = Auto chico)</h3>
        <Button onClick={openCreate} className="bg-blue-600 hover:bg-blue-700 text-white rounded-full" data-testid="admin-service-add-btn"><Plus size={16} className="mr-1.5" /> Nuevo servicio</Button>
      </div>
      <Separator />
      <div className="overflow-x-auto">
        <Table>
          <TableHeader><TableRow><TableHead>Servicio</TableHead><TableHead>Duración</TableHead><TableHead>Precio base (editable)</TableHead><TableHead>SUV (×1.35)</TableHead><TableHead>Grande (×1.7)</TableHead><TableHead></TableHead></TableRow></TableHeader>
          <TableBody>
            {services.map((s) => (
              <TableRow key={s.id} data-testid={`admin-service-${s.id}`}>
                <TableCell><div className="font-semibold">{s.name}</div><div className="text-xs text-slate-500 max-w-xs truncate">{s.description}</div></TableCell>
                <TableCell className="text-sm">{s.duration_minutes} min</TableCell>
                <TableCell>
                  <Input type="number" defaultValue={s.base_price} className="h-9 w-32" data-testid={`admin-service-quickprice-${s.id}`}
                    onBlur={(e) => { if (Number(e.target.value) !== s.base_price) quickEditPrice(s, e.target.value); }} />
                </TableCell>
                <TableCell className="text-sm text-slate-600">{formatARS(Math.round((s.base_price * 1.35) / 100) * 100)}</TableCell>
                <TableCell className="text-sm text-slate-600">{formatARS(Math.round((s.base_price * 1.7) / 100) * 100)}</TableCell>
                <TableCell className="text-right">
                  <Button size="icon" variant="ghost" onClick={() => openEdit(s)} data-testid={`admin-service-edit-${s.id}`}><Pencil size={16} /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(s.id)} data-testid={`admin-service-delete-${s.id}`}><Trash2 size={16} className="text-rose-600" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Editar" : "Nuevo"} servicio</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Nombre</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="admin-service-name" /></div>
            <div><Label>Descripción</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Duración (min)</Label><Input type="number" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })} /></div>
              <div><Label>Precio base (ARS)</Label><Input type="number" value={form.base_price} onChange={(e) => setForm({ ...form, base_price: e.target.value })} data-testid="admin-service-price" /></div>
            </div>
            <div><Label>Badge</Label><Input value={form.badge} onChange={(e) => setForm({ ...form, badge: e.target.value })} /></div>
            <div><Label>Features (una por línea)</Label><textarea className="w-full border rounded-md p-2 text-sm" rows={4} value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })} /></div>
          </div>
          <DialogFooter><Button onClick={submit} data-testid="admin-service-submit" className="bg-blue-600 hover:bg-blue-700">Guardar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

const StatsTab = () => {
  const [stats, setStats] = useState(null);
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [report, setReport] = useState(null);
  const [loadingReport, setLoadingReport] = useState(false);
  useEffect(() => { getStats().then(setStats); }, []);

  const loadReport = async () => {
    try { setLoadingReport(true); const r = await getMonthlyReport(year, month); setReport(r); }
    catch { toast.error("Error al cargar reporte"); }
    finally { setLoadingReport(false); }
  };
  useEffect(() => { loadReport(); }, [year, month]); // eslint-disable-line

  const download = (kind) => {
    const token = localStorage.getItem("ld_token");
    const url = monthlyReportUrl(year, month, kind) + `&t=${encodeURIComponent(token)}`;
    // We need to send Authorization header → use fetch + blob
    fetch(monthlyReportUrl(year, month, kind), { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => { if (!r.ok) throw new Error("err"); return r.blob(); })
      .then((blob) => {
        const u = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = u;
        a.download = `lavadosya-${year}-${String(month).padStart(2, "0")}.${kind === "pdf" ? "pdf" : "xlsx"}`;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(u), 1000);
      })
      .catch(() => toast.error("No se pudo descargar"));
  };

  if (!stats) return <Card className="p-10 bg-white">Cargando…</Card>;
  const MONTHS = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
  const years = [now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1];

  return (
    <div className="space-y-6" data-testid="admin-stats">
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-5 bg-white border-slate-100">
          <h3 className="font-bold text-lg mb-3">Facturación por servicio (todos los tiempos)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={stats.revenue_by_service}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v) => formatARS(v)} />
              <Bar dataKey="value" fill="#0052FF" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card className="p-5 bg-white border-slate-100">
          <h3 className="font-bold text-lg mb-3">Reservas por estado</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={stats.bookings_by_status} dataKey="value" nameKey="status" cx="50%" cy="50%" innerRadius={55} outerRadius={95} paddingAngle={2}>
                {stats.bookings_by_status.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend /><Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Monthly report */}
      <Card className="p-5 bg-white border-slate-100" data-testid="admin-monthly-report">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h3 className="font-bold text-lg flex items-center gap-2">
              <FileText size={18} className="text-blue-600" /> Reporte mensual
            </h3>
            <p className="text-xs text-slate-500">Facturación, servicios y ranking de lavadores.</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
              <SelectTrigger className="w-[140px] h-10" data-testid="report-month-select"><SelectValue /></SelectTrigger>
              <SelectContent>{MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
              <SelectTrigger className="w-[100px] h-10" data-testid="report-year-select"><SelectValue /></SelectTrigger>
              <SelectContent>{years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
            </Select>
            <Button onClick={() => download("pdf")} className="h-10 rounded-full bg-rose-600 hover:bg-rose-700 text-white" data-testid="report-pdf-btn">
              <FileText size={14} className="mr-1.5" /> PDF
            </Button>
            <Button onClick={() => download("xlsx")} className="h-10 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white" data-testid="report-xlsx-btn">
              <FileSpreadsheet size={14} className="mr-1.5" /> Excel
            </Button>
          </div>
        </div>
        <Separator className="my-4" />
        {loadingReport || !report ? (
          <div className="text-sm text-slate-500 py-6 text-center">Calculando reporte…</div>
        ) : (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-3 gap-3">
              <div className="rounded-xl bg-blue-50/60 border border-blue-100 p-4" data-testid="report-kpi-revenue">
                <div className="text-xs text-blue-800 font-semibold uppercase tracking-wider">Facturación del mes</div>
                <div className="font-display font-extrabold text-3xl text-blue-900 mt-1">{formatARS(report.revenue_total)}</div>
              </div>
              <div className="rounded-xl bg-emerald-50/60 border border-emerald-100 p-4" data-testid="report-kpi-completed">
                <div className="text-xs text-emerald-800 font-semibold uppercase tracking-wider">Servicios finalizados</div>
                <div className="font-display font-extrabold text-3xl text-emerald-900 mt-1">{report.bookings_completed}</div>
              </div>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-4" data-testid="report-kpi-total">
                <div className="text-xs text-slate-600 font-semibold uppercase tracking-wider">Reservas totales</div>
                <div className="font-display font-extrabold text-3xl text-slate-900 mt-1">{report.bookings_total}</div>
              </div>
            </div>
            {report.ranking.length > 0 && (
              <div>
                <div className="text-sm font-bold mb-2 flex items-center gap-1.5"><Trophy size={14} className="text-amber-500" /> Ranking de lavadores</div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader><TableRow><TableHead>#</TableHead><TableHead>Lavador</TableHead><TableHead>Servicios</TableHead><TableHead>Facturación</TableHead><TableHead>⭐</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {report.ranking.map((w, i) => (
                        <TableRow key={w.washer} data-testid={`report-rank-${i}`}>
                          <TableCell><Badge className={i === 0 ? "bg-amber-100 text-amber-800 border-amber-200" : "bg-slate-100 text-slate-700 border-slate-200"}>{i + 1}</Badge></TableCell>
                          <TableCell className="font-semibold">{w.washer}</TableCell>
                          <TableCell>{w.count}</TableCell>
                          <TableCell className="font-display font-bold">{formatARS(w.revenue)}</TableCell>
                          <TableCell>{w.avg_rating ?? "—"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>
    </div>
  );
};

const PaymentsTab = () => {
  const [bookings, setBookings] = useState([]);
  const [viewProof, setViewProof] = useState(null);

  const load = () => listBookings().then((d) => setBookings(d.filter((b) => b.payment_method)));
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, []);

  const setStatus = async (id, status) => {
    try { await setPaymentStatus(id, status); toast.success(`Pago ${status}`); load(); }
    catch { toast.error("Error al actualizar"); }
  };

  const grouped = {
    enviado: bookings.filter((b) => b.payment_status === "enviado"),
    verificado: bookings.filter((b) => b.payment_status === "verificado"),
    rechazado: bookings.filter((b) => b.payment_status === "rechazado"),
    pendiente: bookings.filter((b) => b.payment_status === "pendiente"),
  };

  return (
    <div className="space-y-5" data-testid="admin-payments-tab">
      <div className="grid sm:grid-cols-4 gap-3">
        <PayKpi label="Por verificar" value={grouped.enviado.length} tint="amber" testid="pay-kpi-enviado" />
        <PayKpi label="Verificados" value={grouped.verificado.length} tint="emerald" testid="pay-kpi-verificado" />
        <PayKpi label="Rechazados" value={grouped.rechazado.length} tint="rose" testid="pay-kpi-rechazado" />
        <PayKpi label="Sin comprobante" value={grouped.pendiente.length} tint="slate" testid="pay-kpi-pendiente" />
      </div>

      <Card className="bg-white border-slate-100 p-5">
        <h3 className="font-bold text-lg flex items-center gap-2">
          <Receipt size={18} className="text-blue-600" /> Comprobantes por verificar
        </h3>
        {grouped.enviado.length === 0 ? (
          <div className="text-sm text-slate-500 mt-3">No hay comprobantes esperando verificación.</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {grouped.enviado.map((b) => (
              <ProofCard key={b.id} b={b} onView={() => setViewProof(b)} onVerify={() => setStatus(b.id, "verificado")} onReject={() => setStatus(b.id, "rechazado")} />
            ))}
          </div>
        )}
      </Card>

      {(grouped.verificado.length > 0 || grouped.rechazado.length > 0) && (
        <Card className="bg-white border-slate-100 p-5">
          <h3 className="font-bold text-lg">Procesados recientemente</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {[...grouped.verificado, ...grouped.rechazado].slice(0, 9).map((b) => (
              <ProofCard key={b.id} b={b} onView={() => setViewProof(b)} />
            ))}
          </div>
        </Card>
      )}

      {viewProof && (
        <Dialog open onOpenChange={() => setViewProof(null)}>
          <DialogContent className="max-w-2xl" data-testid="proof-view-dialog">
            <DialogHeader><DialogTitle>Comprobante · {viewProof.customer_name}</DialogTitle></DialogHeader>
            {viewProof.payment_proof_url ? (
              <img src={viewProof.payment_proof_url} alt="comprobante" className="rounded-xl w-full max-h-[70vh] object-contain border border-slate-200" />
            ) : (
              <div className="text-center text-slate-500 py-10">No hay imagen de comprobante.</div>
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

const PayKpi = ({ label, value, tint, testid }) => {
  const tints = { amber: "bg-amber-50 text-amber-700 border-amber-200", emerald: "bg-emerald-50 text-emerald-700 border-emerald-200", rose: "bg-rose-50 text-rose-700 border-rose-200", slate: "bg-slate-50 text-slate-700 border-slate-200" };
  return (
    <div className={`rounded-2xl border ${tints[tint]} p-4`} data-testid={testid}>
      <div className="font-display font-extrabold text-3xl">{value}</div>
      <div className="text-xs font-semibold uppercase tracking-wider mt-0.5">{label}</div>
    </div>
  );
};

const ProofCard = ({ b, onView, onVerify, onReject }) => (
  <div className="rounded-2xl border border-slate-200 bg-slate-50/40 p-4" data-testid={`proof-card-${b.id}`}>
    <div className="flex items-start justify-between gap-2">
      <div>
        <div className="font-semibold text-slate-900">{b.customer_name}</div>
        <div className="text-xs text-slate-500">{b.service_name}</div>
      </div>
      <Badge className={b.payment_status === "verificado" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : b.payment_status === "rechazado" ? "bg-rose-100 text-rose-700 border-rose-200" : "bg-amber-100 text-amber-700 border-amber-200"}>
        {b.payment_status}
      </Badge>
    </div>
    <div className="mt-2 text-xs text-slate-600 space-y-0.5">
      <div>{b.payment_method === "transfer" ? "Transferencia BBVA" : "Mercado Pago"}</div>
      <div className="font-display font-bold text-slate-900 text-lg">{formatARS(b.price)}</div>
      <div className="text-slate-500">{formatDate(b.date)} · {b.time} hs</div>
    </div>
    {b.payment_proof_url ? (
      <button onClick={onView} className="mt-3 block w-full group" data-testid={`proof-view-${b.id}`}>
        <img src={b.payment_proof_url} alt="comprobante" className="rounded-xl w-full h-32 object-cover border border-slate-200 group-hover:opacity-80 transition-opacity" />
      </button>
    ) : (
      <div className="mt-3 h-32 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 text-sm">Sin imagen</div>
    )}
    {onVerify && (
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Button onClick={onVerify} size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-full h-9" data-testid={`proof-verify-${b.id}`}>
          <Check size={14} className="mr-1" /> Verificar
        </Button>
        <Button onClick={onReject} size="sm" variant="outline" className="rounded-full h-9 border-rose-200 hover:bg-rose-50 text-rose-700" data-testid={`proof-reject-${b.id}`}>
          <X size={14} className="mr-1" /> Rechazar
        </Button>
      </div>
    )}
  </div>
);

const CouponsTab = () => {
  const [coupons, setCoupons] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ code: "", kind: "percent", value: 10, description: "", active: true, max_uses: "" });

  const load = () => listCoupons().then(setCoupons);
  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm({ code: "", kind: "percent", value: 10, description: "", active: true, max_uses: "" }); setOpen(true); };
  const openEdit = (c) => { setEditing(c); setForm({ ...c, max_uses: c.max_uses ?? "" }); setOpen(true); };

  const submit = async () => {
    const payload = { ...form, value: Number(form.value), max_uses: form.max_uses === "" ? null : Number(form.max_uses) };
    try {
      if (editing) await updateCoupon(editing.id, payload);
      else await createCoupon(payload);
      toast.success(editing ? "Cupón actualizado" : "Cupón creado");
      setOpen(false); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Error"); }
  };
  const remove = async (id) => { try { await deleteCoupon(id); toast.success("Eliminado"); load(); } catch { toast.error("Error"); } };
  const toggle = async (c) => { try { await updateCoupon(c.id, { active: !c.active }); load(); } catch { toast.error("Error"); } };

  return (
    <Card className="bg-white border-slate-100 overflow-hidden" data-testid="admin-coupons-tab">
      <div className="p-5 flex items-center justify-between">
        <h3 className="font-bold text-lg flex items-center gap-2"><Tag size={18} className="text-amber-600" /> Cupones promocionales</h3>
        <Button onClick={openCreate} className="bg-amber-500 hover:bg-amber-600 text-white rounded-full" data-testid="admin-coupon-add-btn">
          <Plus size={16} className="mr-1.5" /> Nuevo cupón
        </Button>
      </div>
      <Separator />
      {coupons.length === 0 ? (
        <div className="p-10 text-center text-slate-500">Todavía no hay cupones. Crea el primero.</div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Código</TableHead><TableHead>Descripción</TableHead><TableHead>Descuento</TableHead><TableHead>Usos</TableHead><TableHead>Activo</TableHead><TableHead></TableHead></TableRow></TableHeader>
            <TableBody>
              {coupons.map((c) => (
                <TableRow key={c.id} data-testid={`admin-coupon-${c.id}`}>
                  <TableCell className="font-mono-ld font-bold text-slate-900">{c.code}</TableCell>
                  <TableCell className="text-sm text-slate-600 max-w-xs">{c.description || "—"}</TableCell>
                  <TableCell><Badge className="bg-amber-50 text-amber-800 border-amber-200">{c.kind === "percent" ? `${c.value}% OFF` : `−${formatARS(c.value)}`}</Badge></TableCell>
                  <TableCell className="text-sm">{c.uses}{c.max_uses ? ` / ${c.max_uses}` : ""}</TableCell>
                  <TableCell>
                    <button onClick={() => toggle(c)} data-testid={`admin-coupon-toggle-${c.id}`}
                      className={`h-6 w-11 rounded-full relative transition-colors ${c.active ? "bg-emerald-500" : "bg-slate-300"}`}>
                      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${c.active ? "left-5" : "left-0.5"}`} />
                    </button>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button size="icon" variant="ghost" onClick={() => openEdit(c)} data-testid={`admin-coupon-edit-${c.id}`}><Pencil size={16} /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(c.id)} data-testid={`admin-coupon-delete-${c.id}`}><Trash2 size={16} className="text-rose-600" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Editar cupón" : "Nuevo cupón"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Código</Label><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} data-testid="admin-coupon-code" className="font-mono-ld uppercase" placeholder="VERANO20" /></div>
            <div><Label>Descripción</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="admin-coupon-desc" placeholder="20% off en lavados de verano" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Tipo</Label>
                <Select value={form.kind} onValueChange={(v) => setForm({ ...form, kind: v })}>
                  <SelectTrigger data-testid="admin-coupon-kind"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percent">Porcentaje (%)</SelectItem>
                    <SelectItem value="fixed">Monto fijo (ARS)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Valor</Label><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} data-testid="admin-coupon-value" /></div>
            </div>
            <div><Label>Usos máximos (opcional)</Label><Input type="number" value={form.max_uses} onChange={(e) => setForm({ ...form, max_uses: e.target.value })} data-testid="admin-coupon-maxuses" placeholder="Vacío = ilimitado" /></div>
          </div>
          <DialogFooter><Button onClick={submit} data-testid="admin-coupon-submit" className="bg-amber-500 hover:bg-amber-600 text-white">Guardar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

const SettingsTab = () => {
  const [staff, setStaff] = useState("");
  const [admin, setAdmin] = useState("");
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => { getSettings().then((s) => setPayment(s.payment_info)); }, []);

  const savePwd = async () => {
    if (!staff && !admin) return toast.error("Ingresá al menos una nueva clave");
    try {
      setLoading(true);
      await changePasswords({ staff_password: staff || undefined, admin_password: admin || undefined });
      toast.success("Claves actualizadas");
      setStaff(""); setAdmin("");
    } catch { toast.error("Error"); } finally { setLoading(false); }
  };

  const savePayment = async () => {
    try { await updatePaymentInfo(payment); toast.success("Datos de pago actualizados"); } catch { toast.error("Error"); }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6" data-testid="admin-settings">
      <Card className="p-6 bg-white border-slate-100">
        <h3 className="font-bold text-lg flex items-center gap-2"><KeyRound size={18} className="text-blue-600" /> Cambiar claves</h3>
        <p className="text-xs text-slate-500 mt-1">Las claves están hasheadas con bcrypt. Dejá en blanco para no cambiar.</p>
        <div className="mt-4 space-y-3">
          <div><Label>Nueva clave de Lavador (Staff)</Label><Input type="password" value={staff} onChange={(e) => setStaff(e.target.value)} data-testid="admin-new-staff-pwd" placeholder="Mín 4 caracteres" /></div>
          <div><Label>Nueva clave de Admin</Label><Input type="password" value={admin} onChange={(e) => setAdmin(e.target.value)} data-testid="admin-new-admin-pwd" placeholder="Mín 4 caracteres" /></div>
          <Button onClick={savePwd} disabled={loading} className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold" data-testid="admin-save-pwd-btn">
            {loading ? "Guardando…" : "Actualizar claves"}
          </Button>
        </div>
      </Card>

      {payment && (
        <Card className="p-6 bg-white border-slate-100">
          <h3 className="font-bold text-lg flex items-center gap-2"><SettingsIcon size={18} className="text-blue-600" /> Datos de pago & WhatsApp</h3>
          <div className="mt-4 space-y-3">
            <div><Label>WhatsApp operativo</Label><Input value={payment.whatsapp} onChange={(e) => setPayment({ ...payment, whatsapp: e.target.value })} data-testid="admin-whatsapp" /></div>
            <div><Label>Precio promocional (ARS)</Label><Input type="number" value={payment.promo_base_price} onChange={(e) => setPayment({ ...payment, promo_base_price: Number(e.target.value) })} data-testid="admin-promo-price" /></div>
            <Separator />
            <div className="font-semibold text-sm">Banco BBVA</div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label className="text-xs">CBU</Label><Input value={payment.bank.cbu} onChange={(e) => setPayment({ ...payment, bank: { ...payment.bank, cbu: e.target.value } })} /></div>
              <div><Label className="text-xs">Alias</Label><Input value={payment.bank.alias} onChange={(e) => setPayment({ ...payment, bank: { ...payment.bank, alias: e.target.value } })} /></div>
            </div>
            <Separator />
            <div className="font-semibold text-sm">Mercado Pago</div>
            <div><Label className="text-xs">Alias MP</Label><Input value={payment.mp.alias} onChange={(e) => setPayment({ ...payment, mp: { ...payment.mp, alias: e.target.value } })} /></div>
            <Button onClick={savePayment} className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white rounded-full font-semibold" data-testid="admin-save-payment-btn">
              Guardar datos de pago
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
};
