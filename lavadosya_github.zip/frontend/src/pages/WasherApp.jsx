import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { MapPicker } from "@/components/MapPicker";
import { ChatDialog } from "@/components/ChatDialog";
import { listBookings, acceptBooking, updateBookingStatus, uploadBookingPhotos, updateWasherLocation } from "@/lib/api";
import { fileToDataUrl } from "@/lib/auth";
import { formatARS, formatDate, STATUS_FLOW } from "@/lib/format";
import { MapPin, Calendar, Clock, Check, X, Navigation, PlayCircle, CheckCircle2, Wrench, Camera, Image as ImageIcon, MessageCircle, Radio } from "lucide-react";

const NEXT_LABEL = {
  aceptado: { next: "en_camino", label: "Estoy en camino", icon: Navigation },
  en_camino: { next: "en_progreso", label: "Empezar lavado", icon: PlayCircle },
  en_progreso: { next: "completado", label: "Marcar completado", icon: CheckCircle2 },
};

export const WasherApp = ({ washer }) => {
  const [pool, setPool] = useState([]);
  const [mine, setMine] = useState([]);
  const [photoBk, setPhotoBk] = useState(null);
  const [chatBk, setChatBk] = useState(null);
  const [sharingId, setSharingId] = useState(null);
  const watchRef = useRef(null);

  const load = async () => {
    const [p, m] = await Promise.all([
      listBookings({ unassigned: true, status: "pendiente" }),
      listBookings(),
    ]);
    setPool(p);
    setMine(m);
  };
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []); // eslint-disable-line

  const stopSharing = () => {
    if (watchRef.current) {
      navigator.geolocation.clearWatch(watchRef.current);
      watchRef.current = null;
    }
    setSharingId(null);
  };

  useEffect(() => () => stopSharing(), []); // cleanup on unmount

  const toggleShareLocation = (b) => {
    if (sharingId === b.id) {
      stopSharing();
      toast.message("Dejaste de compartir ubicación");
      return;
    }
    if (!("geolocation" in navigator)) {
      return toast.error("Tu navegador no soporta geolocalización");
    }
    stopSharing();
    setSharingId(b.id);
    toast.success("Compartiendo tu ubicación en vivo");
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        updateWasherLocation(b.id, pos.coords.latitude, pos.coords.longitude).catch(() => {});
      },
      (err) => {
        toast.error("No se pudo obtener la ubicación", { description: err.message });
        stopSharing();
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );
  };

  const active = mine.filter((b) => b.status !== "completado" && b.status !== "cancelado");
  const done = mine.filter((b) => b.status === "completado");

  const accept = async (id) => {
    try { await acceptBooking(id, washer.id); toast.success("¡Reserva aceptada!"); load(); }
    catch (e) { toast.error("No se pudo aceptar"); }
  };
  const reject = async (id) => {
    toast.message("Rechazaste la solicitud"); setPool((p) => p.filter((b) => b.id !== id));
  };
  const advance = async (b) => {
    const n = NEXT_LABEL[b.status]; if (!n) return;
    try {
      if (b.status === "en_progreso" && !b.after_photo_url) {
        setPhotoBk(b); toast.message("Subí la foto 'después' para completar el lavado"); return;
      }
      await updateBookingStatus(b.id, n.next);
      toast.success("Estado actualizado", { description: n.label });
      if (n.next === "completado") stopSharing();
      load();
    } catch { toast.error("Error al actualizar"); }
  };

  return (
    <div className="space-y-8" data-testid="washer-root">
      <Card className="p-6 sm:p-8 bg-white border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <Badge className="bg-blue-50 text-blue-700 border-blue-100">Lavador independiente</Badge>
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold mt-2 text-slate-900">
            Hola, {washer.name.split(" ")[0]} 👋
          </h1>
          <div className="text-sm text-slate-500 mt-1">Zona: {washer.zone} · ⭐ {washer.rating ?? "–"}</div>
        </div>
        <div className="grid grid-cols-3 gap-3 min-w-full sm:min-w-[380px]">
          <Stat label="Pool" value={pool.length} />
          <Stat label="Activas" value={active.length} />
          <Stat label="Completadas" value={done.length} />
        </div>
      </Card>

      <section>
        <h2 className="font-display text-xl font-bold mb-3 flex items-center gap-2">
          <Wrench size={18} className="text-blue-600" /> Mis lavados en curso
        </h2>
        {active.length === 0 ? (
          <Card className="p-10 text-center bg-white border-dashed border-slate-200"><p className="text-slate-500">No tenés lavados asignados en este momento.</p></Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {active.map((b) => {
              const next = NEXT_LABEL[b.status]; const NextIcon = next?.icon;
              return (
                <Card key={b.id} className="p-5 bg-white border-slate-100" data-testid={`washer-active-${b.id}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-display font-bold text-lg">{b.service_name}</div>
                      <div className="text-xs text-slate-500">{b.vehicle_label} · {b.customer_name}</div>
                      {b.customer_phone && <div className="text-xs text-blue-700 font-mono-ld">{b.customer_phone}</div>}
                    </div>
                    <StatusBadge status={b.status} />
                  </div>
                  <Separator className="my-3" />
                  <div className="space-y-1.5 text-sm text-slate-700">
                    <div className="flex items-center gap-2"><MapPin size={14} className="text-blue-600" /> {b.address} · {b.zone}</div>
                    <div className="flex items-center gap-2"><Calendar size={14} className="text-blue-600" /> {formatDate(b.date)} · <Clock size={14} className="text-blue-600" /> {b.time} hs</div>
                    {b.notes && <div className="text-xs text-slate-500 italic">“{b.notes}”</div>}
                  </div>
                  {b.lat && b.lng && (
                    <div className="mt-3">
                      <MapPicker lat={b.lat} lng={b.lng} readOnly height={140} />
                    </div>
                  )}
                  <Separator className="my-3" />
                  <div className="flex items-center justify-between gap-1 mb-3">
                    {STATUS_FLOW.slice(1).map((_, i) => {
                      const idx = STATUS_FLOW.indexOf(b.status); const reached = idx >= i + 1;
                      return (
                        <div key={i} className="flex-1 flex items-center gap-1 last:flex-none">
                          <div className={`h-2 flex-1 rounded-full ${reached ? "bg-blue-600" : "bg-slate-200"}`} />
                          {i < STATUS_FLOW.length - 2 && <span className={`h-2 w-2 rounded-full ${reached ? "bg-blue-600" : "bg-slate-200"}`} />}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="font-display font-extrabold text-xl">{formatARS(b.price)}</div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Button onClick={() => setChatBk(b)} variant="outline" size="sm" data-testid={`washer-chat-btn-${b.id}`} className="rounded-full h-10 border-blue-200 hover:bg-blue-50">
                        <MessageCircle size={14} className="mr-1" /> Chat
                      </Button>
                      <Button onClick={() => toggleShareLocation(b)} variant={sharingId === b.id ? "default" : "outline"} size="sm" data-testid={`washer-gps-btn-${b.id}`}
                        className={`rounded-full h-10 ${sharingId === b.id ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "border-emerald-200 hover:bg-emerald-50 text-emerald-700"}`}>
                        <Radio size={14} className={`mr-1 ${sharingId === b.id ? "animate-pulse" : ""}`} /> {sharingId === b.id ? "Compartiendo" : "GPS"}
                      </Button>
                      <Button onClick={() => setPhotoBk(b)} variant="outline" size="sm" data-testid={`washer-photos-btn-${b.id}`} className="rounded-full h-10">
                        <Camera size={14} className="mr-1" /> Fotos
                      </Button>
                      {next && (
                        <Button onClick={() => advance(b)} data-testid={`washer-advance-btn-${b.id}`} className="bg-blue-600 hover:bg-blue-700 text-white rounded-full h-10">
                          <NextIcon size={16} className="mr-1.5" /> {next.label}
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <h2 className="font-display text-xl font-bold mb-3">Solicitudes disponibles en CABA / GBA</h2>
        {pool.length === 0 ? (
          <Card className="p-10 text-center bg-white border-dashed border-slate-200"><p className="text-slate-500">No hay solicitudes disponibles.</p></Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {pool.map((b) => (
              <Card key={b.id} className="p-5 bg-white border-slate-100" data-testid={`washer-pool-${b.id}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-display font-bold text-lg">{b.service_name}</div>
                    <div className="text-xs text-slate-500">{b.vehicle_label}</div>
                  </div>
                  <div className="font-display font-extrabold text-xl">{formatARS(b.price)}</div>
                </div>
                <Separator className="my-3" />
                <div className="space-y-1.5 text-sm text-slate-700">
                  <div className="flex items-center gap-2"><MapPin size={14} className="text-blue-600" /> {b.address} · {b.zone}</div>
                  <div className="flex items-center gap-2"><Calendar size={14} className="text-blue-600" /> {formatDate(b.date)} · <Clock size={14} className="text-blue-600" /> {b.time} hs</div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <Button onClick={() => accept(b.id)} data-testid={`washer-accept-btn-${b.id}`} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-full h-10">
                    <Check size={16} className="mr-1.5" /> Aceptar
                  </Button>
                  <Button onClick={() => reject(b.id)} variant="outline" data-testid={`washer-reject-btn-${b.id}`} className="rounded-full h-10 border-slate-200">
                    <X size={16} className="mr-1.5" /> Rechazar
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </section>

      {done.length > 0 && (
        <section>
          <h2 className="font-display text-xl font-bold mb-3">Mi historial</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {done.map((b) => (
              <Card key={b.id} className="p-4 bg-white border-slate-100" data-testid={`washer-done-${b.id}`}>
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-900">{b.service_name}</div>
                  <StatusBadge status={b.status} />
                </div>
                <div className="text-xs text-slate-500 mt-1">{formatDate(b.date)} · {b.zone}</div>
                <div className="mt-2 font-display font-bold">{formatARS(b.price)}</div>
                {b.rating && (
                  <div className="mt-2 flex items-center gap-0.5 text-amber-400">
                    {[1, 2, 3, 4, 5].map((n) => <span key={n}>{n <= b.rating ? "★" : "☆"}</span>)}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </section>
      )}

      {photoBk && <PhotosDialog booking={photoBk} onClose={() => { setPhotoBk(null); load(); }} />}
      {chatBk && <ChatDialog booking={chatBk} me={washer} onClose={() => setChatBk(null)} />}
    </div>
  );
};

const Stat = ({ label, value }) => (
  <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 text-center">
    <div className="font-display font-extrabold text-2xl text-slate-900">{value}</div>
    <div className="text-xs text-slate-500 uppercase tracking-wider font-semibold">{label}</div>
  </div>
);

const PhotosDialog = ({ booking, onClose }) => {
  const [before, setBefore] = useState(booking.before_photo_url || null);
  const [after, setAfter] = useState(booking.after_photo_url || null);
  const [loading, setLoading] = useState(false);

  const onFile = async (setter, file) => {
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) return toast.error("Imagen demasiado grande (máx 3MB)");
    setter(await fileToDataUrl(file));
  };

  const save = async () => {
    try {
      setLoading(true);
      await uploadBookingPhotos(booking.id, { before_photo_url: before, after_photo_url: after });
      toast.success("Fotos guardadas");
      onClose();
    } catch (e) { toast.error("Error al guardar"); } finally { setLoading(false); }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent data-testid="photos-dialog">
        <DialogHeader><DialogTitle>Fotos del servicio</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <PhotoSlot label="Antes" testid="photo-before" url={before} onFile={(f) => onFile(setBefore, f)} />
          <PhotoSlot label="Después" testid="photo-after" url={after} onFile={(f) => onFile(setAfter, f)} />
          <Button onClick={save} disabled={loading} className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full font-semibold" data-testid="photos-save-btn">
            {loading ? "Guardando…" : "Guardar fotos"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const PhotoSlot = ({ label, url, onFile, testid }) => (
  <div>
    <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{label}</div>
    <label className="block border-2 border-dashed border-slate-300 rounded-2xl p-4 cursor-pointer hover:border-blue-400 transition-colors" data-testid={`${testid}-label`}>
      {url ? (
        <img src={url} alt={label} className="rounded-xl w-full h-40 object-cover" />
      ) : (
        <div className="flex flex-col items-center justify-center text-slate-400 py-6">
          <ImageIcon size={28} />
          <span className="text-sm mt-2">Subir imagen</span>
        </div>
      )}
      <input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} data-testid={`${testid}-input`} />
    </label>
  </div>
);
